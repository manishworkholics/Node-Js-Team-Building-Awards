const dotenv = require('dotenv');
dotenv.config();
const Sequelize = require('sequelize')

const BannerModel = require('./../models/banner');
const PartnerModel = require('./../models/partner');
const AdminModel = require('./../models/admin');
const SettingModel = require('./../models/setting');
const CategoryModel = require('./../models/category');
const MasterCategoryModel = require('./../models/masterCategory');
const HostModel = require('./../models/host');
const EventModel = require('./../models/event');
const ContactModel = require('./../models/contact');
const GuestModel = require('./../models/guest');
const BookingModel = require('./../models/booking');

const sequelize = new Sequelize(process.env.db, process.env.user, process.env.password, {
    host: process.env.host,
    dialect: 'mysql',
    timezone: "America/New_York",
    dialectOptions: {
        timezone: "local",
    }
    // logging: true,
    // pool: {
    //     max: 10,
    //     min: 0,
    //     acquire: 30000,
    //     idle: 10000
    // }
})

sequelize.authenticate().then(function (errors) {
    //console.log(errors)
});



const Banner = BannerModel(sequelize, Sequelize);
const Partner = PartnerModel(sequelize, Sequelize);
const Admin = AdminModel(sequelize, Sequelize);
const Setting = SettingModel(sequelize, Sequelize);
const Category = CategoryModel(sequelize, Sequelize);
const MasterCategory = MasterCategoryModel(sequelize, Sequelize);
const Host = HostModel(sequelize, Sequelize);
const Event = EventModel(sequelize, Sequelize);
const Contact = ContactModel(sequelize, Sequelize);
const Guest = GuestModel(sequelize, Sequelize);
const Booking = BookingModel(sequelize, Sequelize);

module.exports = {
    sequelize,
    Banner,
    Partner,
    Admin,
    Setting,
    Category,
    MasterCategory,
    Host,
    Event,
    Contact,
    Guest,
    Booking
}