const express = require('express');
require('dotenv').config();



const router = express.Router();


//======== API Controller =================//
const AdminController = require('../controllers/admin/login');
const AdminBannerController = require('../controllers/admin/banner');
const AdminPartnerController = require('../controllers/admin/partner');
const AdminCMSController = require('../controllers/admin/setting');
const AdminCategoryController = require('../controllers/admin/category');
const AdminMasterCategoryController = require('../controllers/admin/masterCategory');
const AdminHostController = require('../controllers/admin/host');
const AdminEventController = require('../controllers/admin/event');
const AdminContactController = require('../controllers/admin/contact');
const AdminDashboradController = require('../controllers/admin/dashboard');
const AdminGuestsController = require('../controllers/admin/guest');
const AdminMyEarnController = require('../controllers/admin/earn');

const WebsiteHostController = require('../controllers/website/host');
const WebsiteEventController = require('../controllers/website/event');
const WebsiteContactController = require('../controllers/website/contact');
const WebsiteGuestController = require('../controllers/website/guest');
const WebsiteMyEarnController = require('../controllers/website/my_earn');

//========API  Routes =================//
router.prefix('/api', (route) => {
    //Admin API
    // User
    route.post('/admin/login', AdminController.login);
    route.post('/admin/change-password', AdminController.change_password);
    route.post('/admin/update-profile', AdminController.update_profile);
    route.post('/upload-img', AdminController.upload_img);
    route.post('/admin/check-email', AdminController.check_email);

    // Banners
    route.post('/admin/add-banner', AdminBannerController.add_banner);
    route.post('/admin/edit-banner', AdminBannerController.edit_banner);
    route.post('/admin/update-banner', AdminBannerController.update_banner);
    route.post('/admin/delete-banner', AdminBannerController.delete_banner);
    route.post('/admin/list-banner', AdminBannerController.list_banner);

    // Our-partners
    route.post('/admin/add-partner', AdminPartnerController.add_partner);
    route.post('/admin/edit-partner', AdminPartnerController.edit_partner);
    route.post('/admin/update-partner', AdminPartnerController.update_partner);
    route.post('/admin/delete-partner', AdminPartnerController.delete_partner);
    route.post('/admin/list-partner', AdminPartnerController.list_partner);

    // CMS
    route.post('/admin/add-cms', AdminCMSController.add_cms);
    route.post('/admin/get-cms', AdminCMSController.get_cms);
    route.post('/admin/add-settings', AdminCMSController.add_settings);
    
    // Category
    route.post('/admin/add-category', AdminCategoryController.add_category);
    route.post('/admin/edit-category', AdminCategoryController.edit_category);
    route.post('/admin/update-category', AdminCategoryController.update_category);
    route.post('/admin/delete-category', AdminCategoryController.delete_category);
    route.post('/admin/list-category', AdminCategoryController.list_category);
    route.post('/admin/list-category-filtered', AdminCategoryController.list_category_filtered);

    // Master Category
    route.post('/admin/add-master-category', AdminMasterCategoryController.add_master_category);
    route.post('/admin/edit-master-category', AdminMasterCategoryController.edit_master_category);
    route.post('/admin/update-master-category', AdminMasterCategoryController.update_master_category);
    route.post('/admin/delete-master-category', AdminMasterCategoryController.delete_master_category);
    route.post('/admin/list-master-category', AdminMasterCategoryController.list_master_category);

    // Host
    route.post('/admin/list-host', AdminHostController.list_host);
    route.post('/admin/update-host', AdminHostController.update_host);
    route.post('/admin/host-status', AdminHostController.host_status);

    // Event
    route.post('/admin/list-event', AdminEventController.list_event);
    route.post('/admin/list-event-filter', AdminEventController.list_event_filter);
    route.post('/admin/event-status', AdminEventController.event_status);

    // Contact
    route.post('/admin/list-contact', AdminContactController.list_contact);

    // Dashborad
    route.post('/admin/list-dashboard', AdminDashboradController.list_dashboard);
    
    // Guest
    route.post('/admin/list-guest', AdminGuestsController.list_guest);

    // My Earn
    route.post('/admin/list-earn', AdminMyEarnController.list_earn);


    // Website API
    // Host

    route.post('/upload-profile-img', WebsiteHostController.upload_img);
    
    route.post('/web/register', WebsiteHostController.register);
    route.post('/web/check-otp', WebsiteHostController.checkOTP);
    route.post('/web/resend-otp', WebsiteHostController.resendOTP);
    route.post('/web/login', WebsiteHostController.login);
    route.post('/web/forgot-password', WebsiteHostController.forgotPassword);
    route.post('/web/set-new-password', WebsiteHostController.setNewPassword);
    route.post('/web/check-fw-nine-form', WebsiteHostController.check_fw_nine_form);
    route.post('/web/upload-fw-form', WebsiteHostController.upload_fw_form);

    route.post('/web/get-profile', WebsiteHostController.get_profile);
    route.post('/web/change-password', WebsiteHostController.change_password);
    route.post('/web/update-profile', WebsiteHostController.update_profile); 
    route.post('/web/update-bank', WebsiteHostController.update_bank);

    // Event
    route.post('/web/add-event', WebsiteEventController.addEvent);
    route.post('/web/list-category', WebsiteEventController.list_category);
    route.post('/web/list-category-filtered', WebsiteEventController.list_category_filtered);
    route.post('/web/list-master-category', WebsiteEventController.list_master_category);
    route.post('/web/list-events', WebsiteEventController.list_events);
    route.post('/web/update-event', WebsiteEventController.update_event);
    route.post('/web/delete-event', WebsiteEventController.delete_event);

    route.post('/web/event-book', WebsiteEventController.event_book);
    route.post('/web/check-event-booked', WebsiteEventController.check_event_booked);
    route.post('/web/pay-payment', WebsiteEventController.pay_payment);
    route.post('/web/list-guests', WebsiteEventController.list_guests);

    // Contact
    route.post('/web/add-contact', WebsiteContactController.addContact);

    route.post('/web/get-cms', WebsiteContactController.get_cms);
    route.post('/web/list-banner', AdminBannerController.list_banner);
    route.post('/web/list-partner', AdminPartnerController.list_partner);

    // Guest
    route.post('/web/get-guest', WebsiteGuestController.get_guest);
    route.post('/web/update-guest', WebsiteGuestController.update_guest);
    route.post('/web/save-guest', WebsiteGuestController.save_guest);
    route.post('/web/check-booking-pass', WebsiteGuestController.check_booking_pass);
    route.post('/web/list-booked-guests', WebsiteGuestController.list_booked_guests);
    
    // My Earn
    route.post('/web/my-earn', WebsiteMyEarnController.my_earn);

});


module.exports = router;