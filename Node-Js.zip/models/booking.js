'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Booking extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
     static associate(models) {
      // define association here
    }
  };
  Booking.init({
    booking_id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    event_id: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    event_date: {
      type: DataTypes.STRING
    },
    event_time: {
      type: DataTypes.STRING
    },
    price: {
      type: DataTypes.DOUBLE
    },
    event_attendees: {
      type: DataTypes.STRING
    },
    total: {
      type: DataTypes.DOUBLE
    },
    company_name: {
      type: DataTypes.STRING
    },
    first_name: {
      type: DataTypes.STRING
    },
    last_name: {
      type: DataTypes.STRING
    },
    email: {
      type: DataTypes.STRING
    },
    phone: {
      type: DataTypes.STRING
    },
    billing_address_one: {
      type: DataTypes.STRING
    },
    billing_address_two: {
      type: DataTypes.STRING
    },
    country: {
      type: DataTypes.STRING
    },
    state: {
      type: DataTypes.STRING
    },
    city: {
      type: DataTypes.STRING
    },
    post_code: {
      type: DataTypes.STRING
    },
    add_guest_pass: {
      type: DataTypes.STRING
    },
    list_guest_pass: {
      type: DataTypes.STRING
    },
    status: {
      type: DataTypes.INTEGER,
      defaultValue: "0",
      comment: "1=active,0=inactive"
    },
    createdAt: {
      allowNull: false,
      type: DataTypes.DATE
    },
    updatedAt: {
      allowNull: false,
      type: DataTypes.DATE
    }
  }, {
    sequelize,
    modelName: 'Booking',
  });
  return Booking;
};