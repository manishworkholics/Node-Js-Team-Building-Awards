'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Event extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
     static associate(models) {
      // define association here
    }
  };
  Event.init({
    event_id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    host_id: {
      type: DataTypes.INTEGER
    },
    title: {
      type: DataTypes.STRING
    },
    image: {
      type: DataTypes.STRING
    },
    image_one: {
      type: DataTypes.STRING
    },
    image_two: {
      type: DataTypes.STRING
    },
    image_three: {
      type: DataTypes.STRING
    },
    image_four: {
      type: DataTypes.STRING
    },
    short_description: {
      type: DataTypes.STRING
    },
    description: {
      type: DataTypes.STRING
    },
    phone_number: {
      type: DataTypes.STRING
    },
    no_of_guests: {
      type: DataTypes.STRING
    },
    min_guests: {
      type: DataTypes.STRING
    },
    price_per_guest: {
      type: DataTypes.STRING
    },
    event_duration: {
      type: DataTypes.STRING
    },
    master_category_id: {
      type: DataTypes.INTEGER
    },
    category_id: {
      type: DataTypes.INTEGER
    },
    start_date: {
      type: DataTypes.STRING
    },
    start_time: {
      type: DataTypes.STRING
    },
    schedule: {
      type: Array
    },
    event_meeting_link: {
      type: DataTypes.STRING
    },
    how_it_works: {
      type: DataTypes.STRING
    },
    kit_contents:{
      type: DataTypes.STRING
    },
    things_guests_need: {
      type: DataTypes.STRING
    },
    status: {
      type: DataTypes.INTEGER,
      defaultValue: "0",
      comment: "1=active,0=inactive"
    },
    createdAt: {
      allowNull: false,
      type: DataTypes.DATE
    },
    updatedAt: {
      allowNull: false,
      type: DataTypes.DATE
    }
  }, {
    sequelize,
    modelName: 'Event',
  });
  return Event;
};