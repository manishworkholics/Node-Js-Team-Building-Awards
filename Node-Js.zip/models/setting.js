'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Setting extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
     static associate(models) {
      // define association here
    }
  };
  Setting.init({
    term_condition: {
      type: DataTypes.STRING
    },
    privacy_policy: {
      type: DataTypes.STRING
    },
    about_us: {
      type: DataTypes.STRING
    },
    fb_link: {
      type: DataTypes.STRING
    },
    linkedin_link: {
      type: DataTypes.STRING
    },
    twitter_link: {
      type: DataTypes.STRING
    },
    insta_link: {
      type: DataTypes.STRING
    },
    footer_text: {
      type: DataTypes.STRING
    },
    how_it_works: {
      type: DataTypes.STRING
    },
    createdAt: {
      allowNull: false,
      type: DataTypes.DATE
    },
    updatedAt: {
      allowNull: false,
      type: DataTypes.DATE
    }
  }, {
    sequelize,
    modelName: 'Setting',
  });
  return Setting;
};