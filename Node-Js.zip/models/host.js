'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Host extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
     static associate(models) {
      // define association here
    }
  };
  Host.init({
    host_id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    first_name: {
      type: DataTypes.STRING
    },
    last_name: {
      type: DataTypes.STRING
    },
    email: {
      type: DataTypes.STRING
    },
    phone_number: {
      type: DataTypes.STRING
    },
    password: {
      type: DataTypes.STRING
    },
    company_name: {
      type: DataTypes.STRING
    },
    otp: {
      type: DataTypes.STRING
    },
    form_type: {
      type: DataTypes.INTEGER,
      defaultValue: "0",
      comment: "1=W9,2=W8BEN"
    },
    fw_nine_form: {
      type: DataTypes.STRING
    },
    acc_holder_name: {
      type: DataTypes.STRING
    },
    acc_no: {
      type: DataTypes.STRING
    },
    ifsc_code: {
      type: DataTypes.STRING
    },
    bank_name: {
      type: DataTypes.STRING
    },
    branch_name: {
      type: DataTypes.STRING
    },
    paypal_id: {
      type: DataTypes.STRING
    },
    type: {
      type: DataTypes.INTEGER,
      defaultValue: "1",
      comment: "1=normal,2=facebook,3=google,4=apple"
    },
    social_id: {
      type: DataTypes.STRING
    },
    image: {
      type: DataTypes.STRING
    },
    status: {
      type: DataTypes.INTEGER,
      defaultValue: "0",
      comment: "1=active,0=inactive"
    },
    is_active: {
      type: DataTypes.INTEGER,
      defaultValue: "0",
      comment: "1=active,0=inactive"
    },
    createdAt: {
      allowNull: false,
      type: DataTypes.DATE
    },
    updatedAt: {
      allowNull: false,
      type: DataTypes.DATE
    }
  }, {
    sequelize,
    modelName: 'Host',
  });
  return Host;
};