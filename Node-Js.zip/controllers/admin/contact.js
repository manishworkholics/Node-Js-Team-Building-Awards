const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');
var dateFormat = require('dateformat');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Contact,
    sequelize
} = require('../../helpers/DBConnect');

  const list_contact = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    //const contactInfo = await Contact.findAll();

    let contactInfo;
    let where = '';

    if(req.body.startDate!=undefined && req.body.startDate!="" && req.body.endDate==""){
      where += " AND createdAt LIKE '%"+dateFormat(req.body.startDate, "yyyy-mm-dd")+"%'";
  }

  if(req.body.endDate!=undefined && req.body.endDate!="" && req.body.startDate!=""){
      where += " AND createdAt BETWEEN '"+dateFormat(req.body.startDate, "yyyy-mm-dd")+"' AND '"+dateFormat(req.body.endDate, "yyyy-mm-dd")+"' ";
  }

    await sequelize.query("SELECT * FROM 	Contacts WHERE contact_id != 0 "+where+" order by contact_id DESC ", { type: sequelize.QueryTypes.SELECT }).then(async (contactData) => {
      contactInfo = contactData;
      });

       res.status(200).send({
            success: true,
            data: contactInfo,
            message:"",
        });
  });
 
module.exports = {

    list_contact
    
}