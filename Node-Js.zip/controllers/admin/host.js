const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');
var dateFormat = require('dateformat');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Host,
    sequelize
} = require('../../helpers/DBConnect');

  const list_host = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
 
      // const hostInfo = await Host.findAll();
      let hostInfo;
      let where = '';
      if(req.body.form_type!=undefined && req.body.form_type!=""){
            where += " AND form_type = "+req.body.form_type;
        }

        if(req.body.status!=undefined && req.body.status!=""){
            where += " AND is_active = "+req.body.status;
        }

        if(req.body.startDate!=undefined && req.body.startDate!="" && req.body.endDate==""){
            where += " AND createdAt LIKE '%"+dateFormat(req.body.startDate, "yyyy-mm-dd")+"%'";
        }

        if(req.body.endDate!=undefined && req.body.endDate!="" && req.body.startDate!=""){
            where += " AND createdAt BETWEEN '"+dateFormat(req.body.startDate, "yyyy-mm-dd")+"' AND '"+dateFormat(req.body.endDate, "yyyy-mm-dd")+"' ";
        }

   
      await sequelize.query("SELECT * FROM Hosts WHERE host_id != 0 AND is_active != 2 "+where+" ORDER BY host_id DESC ", { type: sequelize.QueryTypes.SELECT }).then(async (hostData) => {
        hostInfo = hostData;
        });

       const hostArr = [];
        if(hostInfo.length > 0){
            for(var i=0;i<hostInfo.length;i++){

                var fw_nine_form = "-";
                if(hostInfo[i]['fw_nine_form']!=null){
                    fw_nine_form = process.env.MAIN_URL + 'uploads/' + hostInfo[i]['fw_nine_form'];
                } 

                var imgs = '';
                if(hostInfo[i]['image']!=null){
                    imgs = process.env.MAIN_URL + 'uploads/' + hostInfo[i]['image'];
                }

                var arr = {
                    'host_id':hostInfo[i]['host_id'],
                    'name':hostInfo[i]['first_name']+' '+hostInfo[i]['last_name'],
                    'email':hostInfo[i]['email'],
                    'phone_number':hostInfo[i]['phone_number'],
                    'image':imgs,
                    'company_name':hostInfo[i]['company_name'],
                    'type':hostInfo[i]['type'],
                    'status':hostInfo[i]['status'],
                    'is_active':hostInfo[i]['is_active'],
                    'form_type':hostInfo[i]['form_type'],
                    'fw_nine_form':fw_nine_form,
                    //'createdAt':dateFormat(hostInfo[i]['createdAt'], "yyyy-mm-dd h:MM")
                    'createdAt':hostInfo[i]['createdAt'],
                    'first_name':hostInfo[i]['first_name'],
                    'last_name':hostInfo[i]['last_name'],
                    'acc_holder_name':hostInfo[i]['acc_holder_name'],
                    'acc_no':hostInfo[i]['acc_no'],
                    'ifsc_code':hostInfo[i]['ifsc_code'],
                    'bank_name':hostInfo[i]['bank_name'],
                    'branch_name':hostInfo[i]['branch_name'],
                    'paypal_id':hostInfo[i]['paypal_id']
                }
                hostArr.push(arr);
            }
        }

       res.status(200).send({
            success: true,
            data: hostArr,
            message:"",
        });
  });
 
const host_status = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const hostResponse = await Host.update({
        is_active: req.body.status,
    },{
        where:{
            host_id:req.body.host_id
        }
    });
    
    if(hostResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Host status updated successfully",
        });
    }

});

const update_host = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    var img = req.body.image;
    var img_path = process.env.MAIN_URL + 'uploads/' + req.body.image;
    if(img == '[object Object]'){

        let checkInfo = null;
        checkInfo = await Host.findOne({
            where: {
                host_id: req.body.host_id
            }
        });

        if(checkInfo.dataValues.image != null){
            img = checkInfo.dataValues.image;
            img_path = process.env.MAIN_URL + 'uploads/' + checkInfo.dataValues.image;
        }else{
            img = null;
            img_path = '/assets/images/user-img.png';
        }

    }

    const hostupdatdata = {
        first_name: req.body.first_name, 
        last_name:req.body.last_name, 
        company_name:req.body.company_name, 
        image:img,
        acc_holder_name:req.body.acc_holder_name ? req.body.acc_holder_name : "", 
        acc_no:req.body.acc_no ? req.body.acc_no : "", 
        ifsc_code:req.body.ifsc_code ? req.body.ifsc_code : "", 
        bank_name:req.body.bank_name ? req.body.bank_name : "", 
        branch_name:req.body.branch_name ? req.body.branch_name : "", 
        paypal_id:req.body.paypal_id ? req.body.paypal_id : "", 
    }
    Host.update(hostupdatdata, {
        where: {
            host_id: req.body.host_id
        }
    });

    res.status(200).send({
        success: true,
        data: img_path,
        message:"Host Uploaded Successfully...!",
    });

});

module.exports = {

    list_host,
    host_status,
    update_host
    
}