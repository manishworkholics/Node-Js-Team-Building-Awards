const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");
var dateFormat = require('dateformat');

const nodemailer = require("nodemailer");

const stripe = require('stripe')('sk_test_51K6T9KKuwTwCP2K3mlJKiBUS20LRhroFoFvkZSIyz2RoUw404tPb4LyElk8R1Qt9Ux0ZtqoTHWYeI1wZQxHpalZZ00Li2G3vpd');

const {
    Host,
    Event,
    Category,
    Booking,
    Guest,
    sequelize
} = require('../../helpers/DBConnect');



  const list_earn = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    await sequelize.query("SELECT e.event_id, e.title, e.image as event_image, e.price_per_guest, e.event_duration, e.category_id, e.createdAt, c.name as category_name,CASE WHEN (SELECT sum(event_attendees) FROM Bookings where event_id=e.event_id) != '' THEN (SELECT sum(event_attendees) FROM Bookings where event_id=e.event_id) ELSE 0 END as event_attendees,CASE WHEN (SELECT sum(total) FROM Bookings where event_id=e.event_id) != '' THEN (SELECT sum(total) FROM Bookings where event_id=e.event_id) ELSE 0 END as event_total_earn,h.host_id,h.first_name,h.last_name,h.email,h.phone_number,h.company_name FROM Events e LEFT JOIN Hosts h ON(e.host_id=h.host_id) LEFT JOIN Categories c ON(c.category_id=e.category_id)  ORDER BY e.event_id DESC", { type: sequelize.QueryTypes.SELECT }).then(async (eventData) => {
      eventInfo = eventData;
      });

      const eventArr = [];
      if(eventInfo.length > 0){
          for(var i=0;i<eventInfo.length;i++){

              var arr = {
                  'event_id':eventInfo[i]['event_id'],
                  'title':eventInfo[i]['title'],
                  'event_image':process.env.MAIN_URL + 'uploads/' + eventInfo[i]['event_image'],
                  'price_per_guest':eventInfo[i]['price_per_guest'],
                  'event_duration':eventInfo[i]['event_duration'],
                  'category_name':eventInfo[i]['category_name'],
                  'category_id':eventInfo[i]['category_id'],
                  'event_attendees':eventInfo[i]['event_attendees'],
                  'event_total_earn':eventInfo[i]['event_total_earn'],
                  'host_name':eventInfo[i]['first_name']+' '+eventInfo[i]['last_name'],
                  'email':eventInfo[i]['email'],
                  'phone_number':eventInfo[i]['phone_number'],
                  'company_name':eventInfo[i]['company_name'],
                  'createdAt':dateFormat(eventInfo[i]['createdAt'], "yyyy-mm-dd h:MM"),
              }
              eventArr.push(arr);
          }
          
      }

       res.status(200).send({
            success: true,
            data: eventArr,
            message:"",
        });

});



module.exports = {

    list_earn
}
