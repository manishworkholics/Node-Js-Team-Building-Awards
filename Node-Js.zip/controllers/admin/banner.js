const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Banner
} = require('../../helpers/DBConnect');

const add_banner = (async (req,res)=>{

  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

  let checkInfo = null;
    checkInfo = await Banner.findOne({
        where: {
            url: req.body.url
        }
    });

if(checkInfo == null){

  var propertyResponse = await Banner.create({
        image: req.body.image,
        url: req.body.url,
        title: req.body.title,
        description: req.body.description,
        status: 1
    });

    if(propertyResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Banner Added Successfully...!",
        });
    }
}else{
    res.status(200).send({
        success: false,
        data: null,
        message:"Banner URL already exist",
    });
}

});

const edit_banner = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const checkInfo = await Banner.findOne({
        where: {
            banner_id: req.body.banner_id
        }
    });

if(checkInfo != null){
        res.status(200).send({
            success: true,
            data: checkInfo,
            message:"",
        });
}else{
    res.status(200).send({
        success: false,
        data: null,
        message:"Not Found",
    });
}

  });

  const update_banner = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const agentResponse = await Banner.update({
        url: req.body.url,
        image: req.body.image,
    },{
        where:{
            banner_id:req.body.banner_id
        }
    });
    
    if(agentResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Banner updated successfully",
        });
    }

  });

  const delete_banner = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    var bannerInfo = await Banner.destroy({
        where: {
            banner_id:req.body.banner_id
        }
    });

    if(bannerInfo){
        res.status(200).send({
            success: true,
            data: null,
            message:"Banner deleted successfully",
        });
    }

  });

  const list_banner = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
       const bannerInfo = await Banner.findAll();

       const bannerArr = [];
        if(bannerInfo.length > 0){
            for(var i=0;i<bannerInfo.length;i++){
                var arr = {
                    'banner_id':bannerInfo[i]['banner_id'],
                    'image':process.env.MAIN_URL + 'uploads/' + bannerInfo[i]['image'],
                    'url':bannerInfo[i]['url'],
                    'title':bannerInfo[i]['title'],
                    'description':bannerInfo[i]['description'],
                    'status':bannerInfo[i]['status'],
                    'createdAt':bannerInfo[i]['createdAt'],
                    'updatedAt':bannerInfo[i]['updatedAt'],
                }
                bannerArr.push(arr);
            }
        }

       res.status(200).send({
            success: true,
            data: bannerArr,
            message:"",
        });
  });
 
module.exports = {

    add_banner,
    edit_banner,
    update_banner,
    delete_banner,
    list_banner
    
}