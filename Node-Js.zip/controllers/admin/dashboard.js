const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');
var dateFormat = require('dateformat');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Contact,
    Event,
    Host,
    Guest,
    Booking
} = require('../../helpers/DBConnect');

  const list_dashboard = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const contactInfo = await Contact.findAll();
    const eventInfo = await Event.findAll();
    const hostInfo = await Host.findAll();
    const guestInfo = await Guest.findAll();
    
    const bookingInfo = await Booking.findAll();
    let total_earn = 0;
    for(var i=0;i<bookingInfo.length;i++){
      total_earn+=bookingInfo[i]['total'];
    }

    const dashboradArr = {
      'contacts':contactInfo.length,
      'events':eventInfo.length,
      'hosts':hostInfo.length,
      'guest':guestInfo.length,
      'earn':total_earn
    }

       res.status(200).send({
            success: true,
            data: dashboradArr,
            message:"",
        });
  });
 
module.exports = {

  list_dashboard
    
}