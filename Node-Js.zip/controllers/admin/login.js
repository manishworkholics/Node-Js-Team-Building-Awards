const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');
const nodemailer = require("nodemailer");

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Admin
} = require('../../helpers/DBConnect');

const login = (async (req,res)=>{

  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    let checkInfo = null;
            checkInfo = await Admin.findOne({
                where: {
                    email: req.body.email,
                    password: md5(req.body.password),
                }
            });

        if(checkInfo == null){
            res.status(200).send({
                success: false,
                data: null,
                message:"Your Email or Password is Wrong",
            });
        }else{
            res.status(200).send({
                success: true,
                data: checkInfo,
                message:"Login Successfully...!",
            });
        }

    });

    const change_password = (async (req,res)=>{

      
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

        if(req.body.new_password == req.body.confirm_password){

            const conditoin = { id: 1 };
            const checkAdmin = await Admin.findOne(conditoin);
            
            if(checkAdmin['password'] == md5(req.body.old_password)){

                const adminupdatdata = {password: md5(req.body.new_password)}
                 Admin.update(adminupdatdata, {
                    where: {
                        id: 1
                    }
                });

                res.status(200).send({
                    success: true,
                    data: null,
                    message:"Password Changed Successfully",
                });

            }else{
                res.status(200).send({
                    success: false,
                    data: null,
                    message:"Old Password is Wrong",
                });
            }

        }else{
            res.status(200).send({
                success: false,
                data: null,
                message:"Confirm Password is Wrong",
            });
        }

    
        });

        const update_profile = (async (req,res)=>{

      
            res.setHeader("Access-Control-Allow-Origin", "*");
            res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
            
          
             const agentResponse = await Admin.update({
                name: req.body.name,
                image: req.body.image,
            },{
                where:{
                    id:1
                }
            });
            
            res.status(200).send({
                success: true,
                data: null,
                message:"Profile updated successfully",
            });

    });

    const upload_img = (async (req,res)=>{
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
      
        const storage = multer.diskStorage({
          
            destination: function (req, file, cb) {
              cb(null, './public/uploads/')
            },
            filename: function(req, file, callback) {
                callback(null, md5(Date.now()) + path.extname(file.originalname));
            }
        });
        
        const uploaFile = multer({
            storage: storage,
        }).single('image');
        
        uploaFile(req, res, async (err) => {
          
            if (!req.file) {
                res.status(500).send({
                  sucecess: false,
                  data: [],
                   message: "Select Image"
                 });
              
            } else if (err) {
              res.status(500).send({
                sucecess: false,
                data: [],
                 message: "not upload"
               });
             
            } else {
      
                res.status(200).send({
                  sucecess: true,
                  data: {filepath_url: req.file.filename,url: process.env.MAIN_URL+"uploads/"+ req.file.filename},
                  message:"",
                });
      
            }
        });
        
      });
      

      const check_email = (async (req,res)=>{

        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        
          let checkInfo = null;
                  checkInfo = await Admin.findOne({
                      where: {
                          email: req.body.email
                      }
                  });
      
              if(checkInfo == null){
                  res.status(200).send({
                      success: false,
                      data: null,
                      message:"Your Email is Wrong",
                  });
              }else{

                var new_password = (Math.random() + 1).toString(36).substring(10);
                
                const adminupdatdata = {password: md5(new_password)}
                 Admin.update(adminupdatdata, {
                    where: {
                        id: 1
                    }
                });

                // Mail Send
                let testAccount = await nodemailer.createTestAccount();

                // create reusable transporter object using the default SMTP transport
                let transporter = nodemailer.createTransport({
                host: process.env.MAIL_HOST,
                port: process.env.MAIL_PORT,
                //secure: false, // true for 465, false for other ports
                auth: {
                    user: process.env.MAIL_USER,
                    pass: process.env.MAIL_PASS,
                },
                });

                var htm = '<html lang="en-US"><head><meta content="text/html; charset=utf-8" http-equiv="Content-Type" /><title>Team Building Awards Event App</title><meta name="description" content="Reset Password Email Template."><style type="text/css">a:hover {text-decoration: underline !important;}</style></head> <body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0"><table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: sans-serif;"><tr><td><table style="background-color: #f2f3f8; max-width:670px;  margin:0 auto;" width="100%" border="0" align="center" cellpadding="0" cellspacing="0"><tr><td style="height:80px;">&nbsp;</td></tr><tr><td style="text-align:center;"><a href="" title="logo" target="_blank"><img src="'+process.env.WEB_URL+'assets/images/logo.png" title="logo" alt="logo"></a></td></tr><tr><td style="height:20px;">&nbsp;</td></tr><tr><td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" style="max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);"><tr><td style="height:40px;">&nbsp;</td></tr><tr><td style="padding:0 35px;"><p style=" margin:0;font-size:18px;font-family:sans-serif;">Hi <b>'+req.body.email+'</b>, <br/></p><span style="display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; width:100px;"></span><p style=" font-size:15px;line-height:24px; margin:0;">Your New Password is: <b>'+new_password+'</b></p><br><br><br>The Team Building Awards Event App </td></tr><tr><td style="height:40px;">&nbsp;</td></tr></table></td><tr><td style="height:20px;">&nbsp;</td></tr><tr><td style="height:80px;">&nbsp;</td></tr></table></td></tr></table></body></html>';

                // send mail with defined transport object
                let info = await transporter.sendMail({
                from: process.env.MAIL_USER, // sender address
                to: req.body.email, // list of receivers
                subject: "Forgot Password", // Subject line
                text: "Forgot Password", // plain text body
                html: htm, // html body
                });
                // =========

                  res.status(200).send({
                      success: true,
                      data: null,
                      message:"Mail send successfully..!Please check your mail..!",
                  });
              }
      
          });

module.exports = {

    login,
    change_password,
    update_profile,
    upload_img,
    check_email
    
}