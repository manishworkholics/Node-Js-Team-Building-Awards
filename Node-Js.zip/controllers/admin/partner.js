const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Partner
} = require('../../helpers/DBConnect');

const add_partner = (async (req,res)=>{

  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

  var propertyResponse = await Partner.create({
        image: req.body.image,
        status: 1
    });

    if(propertyResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Partner Added Successfully...!",
        });
    }


});

const edit_partner = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const checkInfo = await Partner.findOne({
        where: {
            partner_id: req.body.partner_id
        }
    });

if(checkInfo != null){
        res.status(200).send({
            success: true,
            data: checkInfo,
            message:"",
        });
}else{
    res.status(200).send({
        success: false,
        data: null,
        message:"Not Found",
    });
}

  });

  const update_partner = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const agentResponse = await Partner.update({
        image: req.body.image,
    },{
        where:{
            partner_id:req.body.partner_id
        }
    });
    
    if(agentResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Partner updated successfully",
        });
    }

  });

  const delete_partner = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    var partnerInfo = await Partner.destroy({
        where: {
            partner_id:req.body.partner_id
        }
    });

    if(partnerInfo){
        res.status(200).send({
            success: true,
            data: null,
            message:"Partner deleted successfully",
        });
    }

  });

  const list_partner = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
       const partnerInfo = await Partner.findAll();

       const partnerArr = [];
        if(partnerInfo.length > 0){
            for(var i=0;i<partnerInfo.length;i++){
                var arr = {
                    'partner_id':partnerInfo[i]['partner_id'],
                    'image':process.env.MAIN_URL + 'uploads/' + partnerInfo[i]['image'],
                    'status':partnerInfo[i]['status'],
                    'createdAt':partnerInfo[i]['createdAt'],
                    'updatedAt':partnerInfo[i]['updatedAt'],
                }
                partnerArr.push(arr);
            }
        }

       res.status(200).send({
            success: true,
            data: partnerArr,
            message:"",
        });
  });
 
module.exports = {

    add_partner,
    edit_partner,
    update_partner,
    delete_partner,
    list_partner
    
}