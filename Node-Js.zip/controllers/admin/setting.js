const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Setting
} = require('../../helpers/DBConnect');


  const add_cms = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    console.log("A",req.body);
    const cmsResponse = await Setting.update({
        term_condition: req.body.term_condition,
        privacy_policy: req.body.privacy_policy,
        about_us: req.body.about_us,
    },{
        where:{
            id:1
        }
    });
    
    if(cmsResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Saved successfully",
        });
    }

  });


  const add_settings = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    console.log("A",req.body);
    const cmsResponse = await Setting.update({
        fb_link: req.body.fb_link,
        linkedin_link: req.body.linkedin_link,
        twitter_link: req.body.twitter_link,
        insta_link: req.body.insta_link,
        footer_text: req.body.footer_text,
        how_it_works: req.body.how_it_works,
    },{
        where:{
            id:1
        }
    });
    
    if(cmsResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Saved successfully",
        });
    }

  });

  const get_cms = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const checkInfo = await Setting.findOne({
        where: {
            id: 1
        }
    });

if(checkInfo != null){
        res.status(200).send({
            success: true,
            data: checkInfo,
            message:"",
        });
}else{
    res.status(200).send({
        success: false,
        data: null,
        message:"Not Found",
    });
}

  });

module.exports = {

    add_cms,
    get_cms,
    add_settings
    
}