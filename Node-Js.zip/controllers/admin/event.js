const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');
var dateFormat = require('dateformat');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Event,
    sequelize
} = require('../../helpers/DBConnect');

  const list_event = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
       let eventInfo;
        let where = '';

        if(req.body.master_category_id!=undefined && req.body.master_category_id!=""){
            where += " AND e.master_category_id = "+req.body.master_category_id;
        }

        if(req.body.category!=undefined && req.body.category!=""){
            where += " AND e.category_id = "+req.body.category;
        }
    
        if(req.body.duration!=undefined && req.body.duration!=""){
            where += " AND e.event_duration = "+req.body.duration;
        }
    
        if(req.body.price!=undefined && req.body.price!=""){
    
            var price_split = req.body.price.split('-');
            if(price_split.length == 2){
            var min_price = price_split[0];
            var max_price = price_split[1];
    
            where += " AND (e.price_per_guest >= "+min_price+" AND e.price_per_guest <= "+max_price+")";
            }else{
                var min_price = price_split[0];
                where += " AND e.price_per_guest >= "+min_price;
            }
        }

        if(req.body.startDate!=undefined && req.body.startDate!="" && req.body.endDate==""){
            where += " AND e.createdAt LIKE '%"+dateFormat(req.body.startDate, "yyyy-mm-dd")+"%'";
        }

        if(req.body.endDate!=undefined && req.body.endDate!="" && req.body.startDate!=""){
            where += " AND e.createdAt BETWEEN '"+dateFormat(req.body.startDate, "yyyy-mm-dd")+"' AND '"+dateFormat(req.body.endDate, "yyyy-mm-dd")+"' ";
        }

        if(req.body.group!=undefined && req.body.group!=""){

            var group_split = req.body.group.split('-');
            if(group_split.length == 2){
                var min_group = group_split[0];
                var max_group = group_split[1];
    
                where += " AND (e.no_of_guests >= "+min_group+" AND e.no_of_guests <= "+max_group+")";
            }else{
                var min_group = group_split[0];
                where += " AND e.no_of_guests >= "+min_group;
            }
        }

       await sequelize.query("SELECT e.event_id, e.host_id, e.title, e.image, e.image_one, e.image_two, e.image_three, e.image_four, e.short_description, e.description, e.phone_number, e.no_of_guests, e.min_guests, e.price_per_guest, e.event_duration, e.schedule, e.category_id, e.start_date, e.start_time, e.how_it_works, e.things_guests_need, e.status, e.createdAt, e.updatedAt, h.first_name, h.last_name, h.email, h.phone_number, c.name, mc.name AS master_category_name FROM Events e LEFT JOIN Hosts h ON(e.host_id=h.host_id) LEFT JOIN Categories c ON(e.category_id=c.category_id) LEFT JOIN Master_categories mc ON(e.master_category_id=mc.master_category_id) WHERE e.event_id != 0 "+where+" order by e.event_id DESC ", { type: sequelize.QueryTypes.SELECT }).then(async (eventData) => {
        eventInfo = eventData;
        });

       const hostArr = [];
        if(eventInfo.length > 0){
            for(var i=0;i<eventInfo.length;i++){
                var arr = {
                    'event_id':eventInfo[i]['event_id'],
                    'title':eventInfo[i]['title'],
                    'image':process.env.MAIN_URL + 'uploads/' + eventInfo[i]['image'],
                    'image_one':eventInfo[i]['image_one'] != null ? process.env.MAIN_URL + 'uploads/' + eventInfo[i]['image_one'] : '',
                    'image_two':eventInfo[i]['image_two'] != null ? process.env.MAIN_URL + 'uploads/' + eventInfo[i]['image_two'] : '',
                    'image_three':eventInfo[i]['image_three'] != null ? process.env.MAIN_URL + 'uploads/' + eventInfo[i]['image_three'] : '',
                    'image_four':eventInfo[i]['image_four'] != null ? process.env.MAIN_URL + 'uploads/' + eventInfo[i]['image_four'] : '',
                    'description':eventInfo[i]['description'],
                    'short_description':eventInfo[i]['short_description'],
                    'phone_number':eventInfo[i]['phone_number'],
                    'no_of_guests':eventInfo[i]['no_of_guests'],
                    'min_guests':eventInfo[i]['min_guests'],
                    'price_per_guest':eventInfo[i]['price_per_guest'],
                    'event_duration':eventInfo[i]['event_duration'],
                    'start_date':eventInfo[i]['start_date'],
                    'start_time':eventInfo[i]['start_time'],
                    'how_it_works':eventInfo[i]['how_it_works'],
                    'things_guests_need':eventInfo[i]['things_guests_need'],
                    'host_name':eventInfo[i]['first_name']+' '+eventInfo[i]['last_name'],
                    'host_email':eventInfo[i]['email'],
                    'host_phone_number':eventInfo[i]['phone_number'],
                    'master_category_name':eventInfo[i]['master_category_name'],
                    'category_name':eventInfo[i]['name'],
                    'status':eventInfo[i]['status'],
                    'schedule':JSON.parse(eventInfo[i]['schedule']),
                    //'createdAt':dateFormat(eventInfo[i]['createdAt'], "yyyy-mm-dd h:MM")
                    'createdAt':eventInfo[i]['createdAt']
                }
                hostArr.push(arr);
            }
            
        }

       res.status(200).send({
            success: true,
            data: hostArr,
            message:"",
        });
  });

  const list_event_filter = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
       let eventInfo;
        
       await sequelize.query("SELECT event_id,title,image,phone_number,no_of_guests,price_per_guest,event_duration FROM Events WHERE event_id != 0 ORDER BY event_id DESC ", { type: sequelize.QueryTypes.SELECT }).then(async (eventData) => {
        eventInfo = eventData;
        });

       const hostArr = [];
        if(eventInfo.length > 0){
            for(var i=0;i<eventInfo.length;i++){
                var arr = {
                    'event_id':eventInfo[i]['event_id'],
                    'title':eventInfo[i]['title'],
                    'image':process.env.MAIN_URL + 'uploads/' + eventInfo[i]['image'],
                    'phone_number':eventInfo[i]['phone_number'],
                    'no_of_guests':eventInfo[i]['no_of_guests'],
                    'price_per_guest':eventInfo[i]['price_per_guest'],
                    'event_duration':eventInfo[i]['event_duration'],
                }
                hostArr.push(arr);
            }
            
        }

       res.status(200).send({
            success: true,
            data: hostArr,
            message:"",
        });
  });

  const event_status = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const eventResponse = await Event.update({
        status: req.body.status,
    },{
        where:{
            event_id:req.body.event_id
        }
    });
    
    if(eventResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Event status updated successfully",
        });
    }

});
 
module.exports = {

    list_event,
    list_event_filter,
    event_status
    
}