const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    MasterCategory
} = require('../../helpers/DBConnect');

const add_master_category = (async (req,res)=>{

  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

  let checkInfo = null;
    checkInfo = await MasterCategory.findOne({
        where: {
            name: req.body.name
        }
    });

if(checkInfo == null){

  var categoryResponse = await MasterCategory.create({
        name: req.body.name,
        status: 1
    });

    if(categoryResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Category Added Successfully...!",
        });
    }
}else{
    res.status(200).send({
        success: false,
        data: null,
        message:"Category already exist",
    });
}

});

const edit_master_category = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const checkInfo = await MasterCategory.findOne({
        where: {
            master_category_id: req.body.master_category_id
        }
    });

if(checkInfo != null){
        res.status(200).send({
            success: true,
            data: checkInfo,
            message:"",
        });
}else{
    res.status(200).send({
        success: false,
        data: null,
        message:"Not Found",
    });
}

  });

  const update_master_category = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const agentResponse = await MasterCategory.update({
        name: req.body.name,
    },{
        where:{
            master_category_id:req.body.master_category_id
        }
    });
    
    if(agentResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Category updated successfully",
        });
    }

  });

  const delete_master_category = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    var categoryInfo = await MasterCategory.destroy({
        where: {
            master_category_id:req.body.master_category_id
        }
    });

    if(categoryInfo){
        res.status(200).send({
            success: true,
            data: null,
            message:"Category deleted successfully",
        });
    }

  });

  const list_master_category = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
       const categoryInfo = await MasterCategory.findAll();

       const categoryArr = [];
        if(categoryInfo.length > 0){
            for(var i=0;i<categoryInfo.length;i++){
                var arr = {
                    'master_category_id':categoryInfo[i]['master_category_id'],
                    'name':categoryInfo[i]['name'],
                    'status':categoryInfo[i]['status'],
                    'createdAt':categoryInfo[i]['createdAt'],
                    'updatedAt':categoryInfo[i]['updatedAt'],
                }
                categoryArr.push(arr);
            }
        }

       res.status(200).send({
            success: true,
            data: categoryArr,
            message:"",
        });
  });
 
module.exports = {

    add_master_category,
    edit_master_category,
    update_master_category,
    delete_master_category,
    list_master_category
    
}