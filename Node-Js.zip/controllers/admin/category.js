const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Category,
    sequelize
} = require('../../helpers/DBConnect');

const add_category = (async (req,res)=>{

  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

  let checkInfo = null;
    checkInfo = await Category.findOne({
        where: {
            name: req.body.name
        }
    });

if(checkInfo == null){

  var categoryResponse = await Category.create({
        master_category_id: req.body.master_category_id,
        name: req.body.name,
        status: 1
    });

    if(categoryResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Category Added Successfully...!",
        });
    }
}else{
    res.status(200).send({
        success: false,
        data: null,
        message:"Category already exist",
    });
}

});

const edit_category = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const checkInfo = await Category.findOne({
        where: {
            category_id: req.body.category_id
        }
    });

if(checkInfo != null){
        res.status(200).send({
            success: true,
            data: checkInfo,
            message:"",
        });
}else{
    res.status(200).send({
        success: false,
        data: null,
        message:"Not Found",
    });
}

  });

  const update_category = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const agentResponse = await Category.update({
        master_category_id: req.body.master_category_id,
        name: req.body.name,
    },{
        where:{
            category_id:req.body.category_id
        }
    });
    
    if(agentResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Category updated successfully",
        });
    }

  });

  const delete_category = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    var categoryInfo = await Category.destroy({
        where: {
            category_id:req.body.category_id
        }
    });

    if(categoryInfo){
        res.status(200).send({
            success: true,
            data: null,
            message:"Category deleted successfully",
        });
    }

  });

  const list_category = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
     //  const categoryInfo = await Category.findAll();
    
     let categoryInfo;
     await sequelize.query("SELECT c.*,mc.name as master_category_name FROM Categories c LEFT JOIN Master_categories mc ON(mc.master_category_id=c.master_category_id) WHERE c.status=1 ", { type: sequelize.QueryTypes.SELECT }).then(async (catData) => {
        categoryInfo = catData;
        });

       const categoryArr = [];
        if(categoryInfo.length > 0){
            for(var i=0;i<categoryInfo.length;i++){
                var arr = {
                    'category_id':categoryInfo[i]['category_id'],
                    'master_category_id':categoryInfo[i]['master_category_id'],
                    'master_category_name':categoryInfo[i]['master_category_name'],
                    'name':categoryInfo[i]['name'],
                    'status':categoryInfo[i]['status'],
                    'createdAt':categoryInfo[i]['createdAt'],
                    'updatedAt':categoryInfo[i]['updatedAt'],
                }
                categoryArr.push(arr);
            }
        }

       res.status(200).send({
            success: true,
            data: categoryArr,
            message:"",
        });
  });

  const list_category_filtered = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
       const categoryInfo = await Category.findAll({
        where: {
          master_category_id: req.body.master_category_id
        }
    });

       const categoryArr = [];
        if(categoryInfo.length > 0){
            for(var i=0;i<categoryInfo.length;i++){
                var arr = {
                    'category_id':categoryInfo[i]['category_id'],
                    'name':categoryInfo[i]['name'],
                    'status':categoryInfo[i]['status'],
                    'createdAt':categoryInfo[i]['createdAt'],
                    'updatedAt':categoryInfo[i]['updatedAt'],
                }
                categoryArr.push(arr);
            }
        }

       res.status(200).send({
            success: true,
            data: categoryArr,
            message:"",
        });
  });
 
module.exports = {

    add_category,
    edit_category,
    update_category,
    delete_category,
    list_category,
    list_category_filtered
    
}