const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');
var dateFormat = require('dateformat');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
  Booking,
  Guest,
  Event,
  sequelize
} = require('../../helpers/DBConnect');

  const list_guest_old = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    // let guestInfo = null;
    // if(req.body.event_id == 0){
    //    guestInfo = await Guest.findAll();
    // }else{
    //    guestInfo = await Guest.findAll({
    //       where: {
    //           event_id: req.body.event_id
    //       }
    //   });
    // }

    let guestInfo;
    let where = '';
    if(req.body.event_id > 0){
      where += "WHERE g.event_id=" + req.body.event_id + "";
    } 

    await sequelize.query("SELECT g.guest_id, g.event_id, g.name, g.email, g.phone_number, g.status, g.createdAt, g.updatedAt, e.title,e.image FROM Guests g LEFT JOIN Events e ON(e.event_id=g.event_id) "+where+" ", { type: sequelize.QueryTypes.SELECT }).then(async (eventData) => {
      guestInfo = eventData;
      });

      const guestArr = [];
      if(guestInfo.length > 0){
          for(var i=0;i<guestInfo.length;i++){
              var arr = {
                  'guest_id':guestInfo[i]['guest_id'],
                  'event_id':guestInfo[i]['event_id'],
                  'name':guestInfo[i]['name'],
                  'email':guestInfo[i]['email'],
                  'phone_number':guestInfo[i]['phone_number'],
                  'event_name':guestInfo[i]['title'],
                  'image':process.env.MAIN_URL + 'uploads/' + guestInfo[i]['image'],
                  'status':guestInfo[i]['status'],
                  'createdAt':dateFormat(guestInfo[i]['createdAt'], "yyyy-mm-dd h:MM")
              }
              guestArr.push(arr);
          }
          
      }

       res.status(200).send({
            success: true,
            data: guestArr,
            message:"",
        });
  });
 
  const list_guest = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    // let guestInfo;
    // if(req.body.event_id > 0){
    //   guestInfo = await Booking.findAll({
    //     where: {
    //         event_id: req.body.event_id
    //     }
    // });
    // }else{
    //   guestInfo = await Booking.findAll();
    // }



    let guestInfo;
    let where = '';

    if(req.body.event_id > 0){
      where += "AND event_id=" + req.body.event_id + "";
    }

    if(req.body.startDate!=undefined && req.body.startDate!="" && req.body.endDate==""){
      where += " AND createdAt LIKE '%"+dateFormat(req.body.startDate, "yyyy-mm-dd")+"%'";
  }

  if(req.body.endDate!=undefined && req.body.endDate!="" && req.body.startDate!=""){
      where += " AND createdAt BETWEEN '"+dateFormat(req.body.startDate, "yyyy-mm-dd")+"' AND '"+dateFormat(req.body.endDate, "yyyy-mm-dd")+"' ";
  }

  if(req.body.eventDate!=undefined && req.body.eventDate!="" && req.body.endDate==""){
    where += " AND event_date LIKE '%"+dateFormat(req.body.eventDate, "yyyy-mm-dd")+"%'";
}

if(req.body.event!=undefined && req.body.event!="" && req.body.endDate==""){
  where += " AND event_id = "+req.body.event;
}

    await sequelize.query("SELECT * FROM Bookings WHERE booking_id != 0 "+where+" order by booking_id DESC ", { type: sequelize.QueryTypes.SELECT }).then(async (bookingData) => {
      guestInfo = bookingData;
      });



  //  let guestInfo;

  //      await sequelize.query(" select b.*,e.title,e.no_of_guests,e.event_duration from Bookings b LEFT JOIN Events e ON(b.event_id=b.event_id) ", { type: sequelize.QueryTypes.SELECT }).then(async (BookingData) => {
  //       guestInfo = BookingData;
  //       });

       const guestArr = [];
        if(guestInfo.length > 0){
            for(var i=0;i<guestInfo.length;i++){
                
                const guestInfos = await Guest.findAll({
                    where: {
                        booking_id: guestInfo[i]['booking_id']
                    }
                });

                const eventInfos = await Event.findOne({
                  where: {
                      event_id: guestInfo[i]['event_id']
                  }
              });

              if(eventInfos){
                eventInfos.dataValues.image = process.env.MAIN_URL + 'uploads/' + eventInfos.dataValues.image;
              }
                var arr = {
                    'booking_id':guestInfo[i]['booking_id'],
                    'event_id':guestInfo[i]['event_id'],
                    'event_date':guestInfo[i]['event_date'],
                    'event_time':guestInfo[i]['event_time'],
                    'event_attendees':guestInfo[i]['event_attendees'],
                    'company_name':guestInfo[i]['company_name'],
                    'first_name':guestInfo[i]['first_name'],
                    'last_name':guestInfo[i]['last_name'],
                    'email':guestInfo[i]['email'],
                    'phone':guestInfo[i]['phone'],
                    'billing_address_one':guestInfo[i]['billing_address_one'],
                    'billing_address_two':guestInfo[i]['billing_address_two'],
                    'country':guestInfo[i]['country'],
                    'state':guestInfo[i]['state'],
                    'city':guestInfo[i]['city'],
                    'post_code':guestInfo[i]['post_code'],
                    'price':guestInfo[i]['price'],
                    'total':guestInfo[i]['total'],
                    //'createdAt':dateFormat(guestInfo[i]['createdAt'], "yyyy-mm-dd h:MM"),
                    'createdAt':guestInfo[i]['createdAt'],
                    'guests':guestInfos,
                    'event':eventInfos
                }

                guestArr.push(arr);
            }
        }

       res.status(200).send({
            success: true,
            data: guestArr,
            message:"",
        });

});


module.exports = {

  list_guest
    
}