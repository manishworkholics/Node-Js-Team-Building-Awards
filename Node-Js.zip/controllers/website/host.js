const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');

const nodemailer = require("nodemailer");

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Host,
    sequelize
} = require('../../helpers/DBConnect');

const upload_img = (async (req,res)=>{
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  
    const storage = multer.diskStorage({
      
        destination: function (req, file, cb) {
          cb(null, './public/uploads/')
        },
        filename: function(req, file, callback) {
            callback(null, md5(Date.now()) + path.extname(file.originalname));
        }
    });
    
    const uploaFile = multer({
        storage: storage,
    }).single('image');
    
    uploaFile(req, res, async (err) => {
      
        if (!req.file) {
            res.status(500).send({
              sucecess: false,
              data: [],
               message: "Select Image"
             });
          
        } else if (err) {
          res.status(500).send({
            sucecess: false,
            data: [],
             message: "not upload"
           });
         
        } else {
  
            res.status(200).send({
              sucecess: true,
              data: {filepath_url: req.file.filename,url: process.env.MAIN_URL+"uploads/"+ req.file.filename},
              message:"",
            });
  
        }
    });
    
  });

const register = (async (req,res)=>{
    res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    if(req.body.type==1){
        

        let checkInfo = null;
        checkInfo = await Host.findOne({
            where: {
                [Op.or]:[
                    {
                        email: req.body.email
                    },
                    {
                        phone_number: req.body.phone_number

                    }
                ]
            }
        });
 
        if(checkInfo == null){
            var newOtp = Math.floor(10000 + Math.random() * 90000);
            //var newOtp = '12345';
            const hotResponse = await Host.create({
                first_name: req.body.first_name,
                last_name: req.body.last_name,
                email: req.body.email,
                phone_number: req.body.phone_number,
                password: md5(req.body.password),
                company_name: req.body.company_name,
                otp: newOtp,
                type:1,
                status: 0
            });
        
            if(hotResponse){

                var name = req.body.first_name+' '+req.body.last_name;
                var otp = newOtp;
                sendMailOTP(name,req.body.email,otp);

                res.status(200).send({
                    success: true,
                    data: hotResponse,
                    message:"Register Successfully...!",
                });
            }
        }else{

            if(checkInfo['status']==1){
                res.status(200).send({
                    success: false,
                    data: null,
                    message:"Already Registred.Please Login...!",
                });
            }else{
                
                var newOtp = Math.floor(100000 + Math.random() * 900000);
                const hostsResponse = await Host.update({
                    otp: newOtp,
                },{
                    where:{
                        host_id:checkInfo['host_id']
                    }
                });
                
                if(hostsResponse){
                    res.status(200).send({
                        success: true,
                        data: null,
                        message:"OTP Send Successfully...!",
                    });
                }

            }
        }

    }else{
        let checkSocialInfo = null;
        checkSocialInfo = await Host.findOne({
            where: {
                social_id: req.body.social_id
            }
        });

        if(checkSocialInfo == null){
            const hotResponse = await Host.create({
                first_name: req.body.first_name,
                last_name: req.body.last_name,
                email: req.body.email,
                password: "",
                company_name: "",
                otp: "",
                phone_number: req.body.phone_number,
                type:req.body.type,
                social_id:req.body.social_id,
                status: 1
            });
        
            if(hotResponse){

                let getHost_id = null;
                getHost_id = await Host.findOne({
                    where: {
                        social_id: req.body.social_id
                    }
                });

                const successData = {
                    name: req.body.first_name,
                    email: req.body.email,
                    phone_number: req.body.phone_number,
                    host_id:getHost_id.dataValues.host_id
                }
                res.status(200).send({
                    success: true,
                    data: successData,
                    message:"Login Successfully...!",
                });
            }
        }else if(req.body.social_id == checkSocialInfo['social_id']){


            let getHost_id = null;
            getHost_id = await Host.findOne({
                where: {
                    social_id: req.body.social_id
                }
            });

            const successData = {
                name: req.body.first_name,
                email: req.body.email,
                phone_number: req.body.phone_number,
                host_id:getHost_id.dataValues.host_id
            }
            res.status(200).send({
                success: true,
                data: successData,
                message:"Login Successfully...!",
            });
        }

    }

    
  });

  const login = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  
      let checkInfo = null;
              checkInfo = await Host.findOne({
                  where: {
                      email: req.body.email,
                      password: md5(req.body.password),
                  }
              });
          
          if(checkInfo == null){
              res.status(200).send({
                  success: false,
                  type:2,
                  data: null,
                  message:"Your Email or Password is Wrong",
              });
          }else if(checkInfo['status']==0){

            var newOtp = Math.floor(10000 + Math.random() * 90000);
            //var newOtp = '12345';
            const hostupdatdata = {otp: newOtp}
                Host.update(hostupdatdata, {
                    where: {
                        email: req.body.email,
                    }
                });

                var name = checkInfo['first_name']+' '+checkInfo['last_name'];
                var otp = newOtp;
               // sendMailOTP(name,req.body.email,otp);

            res.status(200).send({
                success: false,
                type:3,
                data: checkInfo,
                message:"Please verify OTP",
            });
          }else if(checkInfo['is_active']==0){
            res.status(200).send({
                success: false,
                type:4,
                data: null,
                message:"Your Account is Inactive",
            });
          }else{
            
            if(checkInfo.dataValues.image != null){
                checkInfo['image'] = process.env.MAIN_URL + 'uploads/' + checkInfo.dataValues.image;
            }else{
                checkInfo['image'] = '/assets/images/user-img.png';
            }

              res.status(200).send({
                  success: true,
                  type:1,
                  data: checkInfo,
                  message:"Login Successfully...!",
              });
          }
  
      });

      const checkOTP = (async (req,res)=>{

        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        
        
          let checkInfo = null;
                  checkInfo = await Host.findOne({
                      where: {
                          email: req.body.email,
                          otp: req.body.otp,
                      }
                  });
              
              if(checkInfo == null){
                  res.status(200).send({
                      success: false,
                      data: null,
                      message:"Your OTP is Wrong",
                  });
              }else{

                const hostupdatdata = {status: 1}
                Host.update(hostupdatdata, {
                    where: {
                        email: req.body.email
                    }
                });

                checkInfo['status'] = 1;

                  res.status(200).send({
                      success: true,
                      data: checkInfo,
                      message:"Login Successfully...!",
                  });
              }
      
          });

          const resendOTP = (async (req,res)=>{

            res.setHeader("Access-Control-Allow-Origin", "*");
            res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
            
            
            let checkInfo = null;
            checkInfo = await Host.findOne({
                where: {
                    email: req.body.email
                }
            });
        

        if(checkInfo == null){
            res.status(200).send({
                success: false,
                data: null,
                message:"Your Email is Wrong",
            });
        }else{

            var newOtp = Math.floor(10000 + Math.random() * 90000);
          const hostupdatdata = {otp: newOtp}
          Host.update(hostupdatdata, {
              where: {
                email: req.body.email
              }
          });

          var name = checkInfo.dataValues.first_name+' '+checkInfo.dataValues.last_name;
          var otp = newOtp;
          sendMailOTP(name,req.body.email,otp);

            res.status(200).send({
                success: true,
                data: null,
                message:"Resend OTP Successfully...!",
            });
        }

    
        });

    const forgotPassword = (async (req,res)=>{

        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

        let checkInfo = null;
        checkInfo = await Host.findOne({
            where: {
                email: req.body.email
            }
        });
    
    if(checkInfo == null){
        res.status(200).send({
            success: false,
            data: null,
            message:"Your Email is Wrong",
        });
    }else{
        var name = checkInfo['first_name']+' '+checkInfo['last_name'];
        var link = process.env.WEB_URL+"reset-password/"+md5(checkInfo['host_id'].toString());
        sendMailFun(name,req.body.email,link);

        res.status(200).send({
            success: true,
            data: link,
            message:"Mail Send Successfully. Check your Mail..!",
        });
    }

    });


    const setNewPassword = (async (req,res)=>{

        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

        let hostInfo;

       await sequelize.query(" select host_id from Hosts WHERE md5(host_id) = '"+req.body.host_id+"' ", { type: sequelize.QueryTypes.SELECT }).then(async (hostData) => {
        hostInfo = hostData;
        });

        if(hostInfo.length > 0){
        var host_id = hostInfo[0]['host_id'];

        const hostupdatdata = {password: md5(req.body.password)}
                Host.update(hostupdatdata, {
                    where: {
                        host_id: host_id
                    }
                });

                res.status(200).send({
                    success: true,
                    data: null,
                    message:"Password Reset Successfully...!",
                });

            }else{
                res.status(200).send({
                    success: false,
                    data: null,
                    message:"Host is not exist",
                });
            }

    });


    const check_fw_nine_form = (async (req,res)=>{

        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    
        let checkInfo = null;
        checkInfo = await Host.findOne({
            where: {
                host_id: req.body.host_id
            }
        });

        if(checkInfo!=null){
        if(checkInfo.dataValues.fw_nine_form == null){
            res.status(200).send({
                success: true,
                data: null,
                message:"",
            });
        }else{
            res.status(200).send({
                success: false,
                data: {form_type:checkInfo.dataValues.form_type,fw_nine_form:process.env.MAIN_URL + 'uploads/' + checkInfo.dataValues.fw_nine_form},
                message:"",
            });
        }
    }else{
        res.status(200).send({
            success: false,
            data: {form_type:checkInfo.dataValues.form_type,fw_nine_form:process.env.MAIN_URL + 'uploads/' + checkInfo.dataValues.fw_nine_form},
            message:"",
        });
    }
    
    });
 

const upload_fw_form = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    const hostupdatdata = {fw_nine_form: req.body.fw_nine_form, form_type:req.body.form_type}
    Host.update(hostupdatdata, {
        where: {
            host_id: req.body.host_id
        }
    });

    res.status(200).send({
        success: true,
        data: null,
        message:"Form Uploaded Successfully...!",
    });

});

const get_profile = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    let checkInfo = null;
        checkInfo = await Host.findOne({
            where: {
                host_id: req.body.host_id
            }
        });

    const data = {};
    if(checkInfo!=''){
        data['first_name'] = checkInfo.dataValues.first_name;
        data['last_name'] = checkInfo.dataValues.last_name;
        data['company_name'] = checkInfo.dataValues.company_name;
        data['email'] = checkInfo.dataValues.email;
        data['phone_number'] = checkInfo.dataValues.phone_number;

        data['acc_holder_name'] = checkInfo.dataValues.acc_holder_name;
        data['acc_no'] = checkInfo.dataValues.acc_no;
        data['ifsc_code'] = checkInfo.dataValues.ifsc_code;
        data['bank_name'] = checkInfo.dataValues.bank_name;
        data['branch_name'] = checkInfo.dataValues.branch_name;
        data['paypal_id'] = checkInfo.dataValues.paypal_id;

        if(checkInfo.dataValues.image != null){
            data['image'] = process.env.MAIN_URL + 'uploads/' + checkInfo.dataValues.image;
        }else{
            data['image'] = checkInfo.dataValues.image;
        }

    }

    res.status(200).send({
        success: true,
        data: data,
        message:"",
    });

});

const change_password = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    if(req.body.new_password == req.body.confirm_password){

        const conditoin = { id: 1 };
        const checkHost = await Host.findOne(conditoin);
        
        if(checkHost['password'] == md5(req.body.old_password)){

            const hostupdatdata = {password: md5(req.body.new_password)}
             Host.update(hostupdatdata, {
                where: {
                    host_id: req.body.host_id
                }
            });

            res.status(200).send({
                success: true,
                data: null,
                message:"Password Changed Successfully",
            });

        }else{
            res.status(200).send({
                success: false,
                data: null,
                message:"Old Password is Wrong",
            });
        }

    }else{
        res.status(200).send({
            success: false,
            data: null,
            message:"Confirm Password is Wrong",
        });
    }

});

const update_profile = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    var img = req.body.image;
    var img_path = process.env.MAIN_URL + 'uploads/' + req.body.image;
    if(img == '[object Object]'){

        let checkInfo = null;
        checkInfo = await Host.findOne({
            where: {
                host_id: req.body.host_id
            }
        });

        if(checkInfo.dataValues.image != null){
            img = checkInfo.dataValues.image;
            img_path = process.env.MAIN_URL + 'uploads/' + checkInfo.dataValues.image;
        }else{
            img = null;
            img_path = '/assets/images/user-img.png';
        }

    }

    const hostupdatdata = {first_name: req.body.first_name, last_name:req.body.last_name, company_name:req.body.company_name, image:img}
    Host.update(hostupdatdata, {
        where: {
            host_id: req.body.host_id
        }
    });

    res.status(200).send({
        success: true,
        data: img_path,
        message:"Profile Uploaded Successfully...!",
    });

});

const update_bank = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");


    const hostupdatdata = {acc_holder_name: req.body.acc_holder_name, acc_no:req.body.acc_no, ifsc_code:req.body.ifsc_code, bank_name:req.body.bank_name, branch_name:req.body.branch_name, paypal_id:req.body.paypal_id}
    Host.update(hostupdatdata, {
        where: {
            host_id: req.body.host_id
        }
    });

    res.status(200).send({
        success: true,
        data: null,
        message:"Bank Details Updated Successfully...!",
    });

});

module.exports = {

    upload_img,
    register,
    login,
    checkOTP,
    resendOTP,
    forgotPassword,
    setNewPassword,
    check_fw_nine_form,
    upload_fw_form,
    get_profile,
    change_password,
    update_profile,
    update_bank
    
}

async function sendMailFun(name,email,link){
    // Mail Send
  
   // let testAccount = await nodemailer.createTestAccount();
  
    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
        host: process.env.MAIL_HOST,
        port: process.env.MAIL_PORT,
        //secure: false, // true for 465, false for other ports
        auth: {
            user: process.env.MAIL_USER,
            pass: process.env.MAIL_PASS,
        },
        });
  
    var htm = '<html lang="en-US"><head><meta content="text/html; charset=utf-8" http-equiv="Content-Type" /><title>Elloro</title><meta name="description" content="Reset Password Email Template."><style type="text/css">a:hover {text-decoration: underline !important;}</style></head> <body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0"><table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: sans-serif;"><tr><td><table style="background-color: #f2f3f8; max-width:670px;  margin:0 auto;" width="100%" border="0" align="center" cellpadding="0" cellspacing="0"><tr><td style="height:80px;">&nbsp;</td></tr><tr><td style="text-align:center;"><a href="" title="logo" target="_blank"><img src="'+process.env.WEB_URL+'assets/images/logo.png" title="logo" alt="logo"></a></td></tr><tr><td style="height:20px;">&nbsp;</td></tr><tr><td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" style="max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);"><tr><td style="height:40px;">&nbsp;</td></tr><tr><td style="padding:0 35px;"><p style=" margin:0;font-size:18px;font-family:sans-serif;">Hi <b>'+name+'</b>, <br/></p><span style="display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; width:100px;"></span><p style=" font-size:15px;line-height:24px; margin:0;">Your Reset Password Link is: <a href='+link+'>'+link+'</a></p><br><br><br>The Team Building Awards Team </td></tr><tr><td style="height:40px;">&nbsp;</td></tr></table></td><tr><td style="height:20px;">&nbsp;</td></tr><tr><td style="height:80px;">&nbsp;</td></tr></table></td></tr></table></body></html>';
  
    // send mail with defined transport object
    let info = await transporter.sendMail({
      from: process.env.MAIL_USER, // sender address
      to: email, // list of receivers
      subject: "Forgot Password", // Subject line
      text: "Forgot Password", // plain text body
      html: htm, // html body
    });
    // =========
  }

  async function sendMailOTP(name,email,otp){
    // Mail Send
  
   // let testAccount = await nodemailer.createTestAccount();
  
    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
        host: process.env.MAIL_HOST,
        port: process.env.MAIL_PORT,
        //secure: false, // true for 465, false for other ports
        auth: {
            user: process.env.MAIL_USER,
            pass: process.env.MAIL_PASS,
        },
        });
  
    var htm = '<html lang="en-US"><head><meta content="text/html; charset=utf-8" http-equiv="Content-Type" /><title>Elloro</title><meta name="description" content="Reset Password Email Template."><style type="text/css">a:hover {text-decoration: underline !important;}</style></head> <body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0"><table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: sans-serif;"><tr><td><table style="background-color: #f2f3f8; max-width:670px;  margin:0 auto;" width="100%" border="0" align="center" cellpadding="0" cellspacing="0"><tr><td style="height:80px;">&nbsp;</td></tr><tr><td style="text-align:center;"><a href="" title="logo" target="_blank"><img src="'+process.env.WEB_URL+'assets/images/logo.png" title="logo" alt="logo"></a></td></tr><tr><td style="height:20px;">&nbsp;</td></tr><tr><td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" style="max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);"><tr><td style="height:40px;">&nbsp;</td></tr><tr><td style="padding:0 35px;"><p style=" margin:0;font-size:18px;font-family:sans-serif;">Hi <b>'+name+'</b>, <br/></p><span style="display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; width:100px;"></span><p style=" font-size:15px;line-height:24px; margin:0;">Your OTP is: '+otp+'</p><br><br><br>The Team Building Awards Team </td></tr><tr><td style="height:40px;">&nbsp;</td></tr></table></td><tr><td style="height:20px;">&nbsp;</td></tr><tr><td style="height:80px;">&nbsp;</td></tr></table></td></tr></table></body></html>';
  
    // send mail with defined transport object
    let info = await transporter.sendMail({
      from: process.env.MAIL_USER, // sender address
      to: email, // list of receivers
      subject: "Verify OTP", // Subject line
      text: "Verify OTP", // plain text body
      html: htm, // html body
    });
    // =========
  }