const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Guest,
    Booking,
    sequelize
} = require('../../helpers/DBConnect');


  const get_guest = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    

    let guestInfo;

       await sequelize.query(" select guest_id, booking_id, event_id, name, last_name, email, phone_number, address from Guests WHERE md5(guest_id) = '"+req.body.guest_id+"' ", { type: sequelize.QueryTypes.SELECT }).then(async (guestData) => {
        guestInfo = guestData;
        });

if(guestInfo != null){
        res.status(200).send({
            success: true,
            data: guestInfo[0],
            message:"",
        });
}else{
    res.status(200).send({
        success: false,
        data: null,
        message:"Not Found",
    });
}

  });


  const update_guest = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    const guestResponse = await Guest.update({
        name: req.body.name,
        last_name: req.body.last_name,
        address: req.body.address,
        phone_number: req.body.phone,
    },{
        where:{
            guest_id:req.body.guest_id
        }
    });
    
    if(guestResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Guest saved successfully",
        });
    }

});

const save_guest = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");


    let getBooking;

       await sequelize.query(" select booking_id,event_id,event_attendees from Bookings WHERE md5(booking_id) = '"+req.body.booking_id+"' ", { type: sequelize.QueryTypes.SELECT }).then(async (bookikngData) => {
        getBooking = bookikngData;
        });

        let countGuestInfo = null;
        countGuestInfo = await Guest.findAll({
            where: {
                booking_id:getBooking[0]['booking_id']
            }
        });

        if(countGuestInfo.length < getBooking[0]['event_attendees']){

        let checkGuestInfo = null;
        checkGuestInfo = await Guest.findOne({
            where: {
                booking_id:getBooking[0]['booking_id'],
                email:req.body.email
            }
        });
      
        if(!checkGuestInfo){

    const guestResponse = await Guest.create({
        name: req.body.name,
        last_name: req.body.last_name,
        address: req.body.address,
        email: req.body.email,
        phone_number: req.body.phone,
        booking_id:getBooking[0]['booking_id'],
        event_id: getBooking[0]['event_id'],
        status:1
    });
    
    if(guestResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Guest saved successfully",
        });
    }

}else{
    res.status(200).send({
        success: false,
        data: null,
        message:"Guest already registred",
    });
}

}else{
    res.status(200).send({
        success: false,
        data: null,
      //  message:"Guest Participation limit has been Over",
      message:"Your guest participation limit has been reached. Please contact admin@teambuildingawards.com to add participants. ",
    });
}

});
 
const check_booking_pass = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");


    let getBooking;

       await sequelize.query(" select booking_id,event_id,add_guest_pass,list_guest_pass from Bookings WHERE md5(booking_id) = '"+req.body.booking_id+"' ", { type: sequelize.QueryTypes.SELECT }).then(async (bookikngData) => {
        getBooking = bookikngData;
        });

        var is_verify = 0;
        if(req.body.type == 'add'){
            
            if(req.body.password == getBooking[0]['add_guest_pass']){
                is_verify = 1;
            }

        }else{
            if(req.body.password == getBooking[0]['list_guest_pass']){
                is_verify = 1;
            }
        }
        
    if(is_verify == 1){
        res.status(200).send({
            success: true,
            data: null,
            message:"Verify successfully",
        });
    }else{
        res.status(200).send({
            success: false,
            data: null,
            message:"Password is Wrong",
        });
    }
    

});

const list_booked_guests = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");


    let getGuests;

       await sequelize.query(" select g.`guest_id`, g.`booking_id`, g.`event_id`, g.`name`, g.`last_name`, g.`email`, g.`phone_number`, g.`address`, g.`status`, g.`createdAt` from Bookings b LEFT JOIN Guests g ON(b.booking_id=g.booking_id) WHERE md5(b.booking_id) = '"+req.body.booking_id+"' ", { type: sequelize.QueryTypes.SELECT }).then(async (guestsData) => {
        getGuests = guestsData;
        });

        let getBooking;

       await sequelize.query(" select b.*,e.title,e.no_of_guests,e.event_duration from Bookings b LEFT JOIN Events e ON(b.event_id=e.event_id) WHERE md5(b.booking_id) = '"+req.body.booking_id+"' ", { type: sequelize.QueryTypes.SELECT }).then(async (BookingData) => {
        getBooking = BookingData;
        });

        res.status(200).send({
            success: true,
            data: {booking:getBooking, guests:getGuests},
            message:"",
        });

});

module.exports = {

    get_guest,
    update_guest,
    save_guest,
    check_booking_pass,
    list_booked_guests
    
}