const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");

const {
    Contact,
    Setting
} = require('../../helpers/DBConnect');


const addContact = (async (req,res)=>{
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

  const contactResponse = await Contact.create({
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    email: req.body.email,
    phone_number: req.body.phone_number,
    how_we_can_help_you: req.body.how_we_can_help_you,
    company_name: req.body.company_name,
    message: req.body.message,
    status: 1
});

if(contactResponse){
    res.status(200).send({
        success: true,
        data: null,
        message:"Contact Saved Successfully...!",
    });
}
    
  });

  const get_cms = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    const checkInfo = await Setting.findOne({
        where: {
            id: 1
        }
    });

if(checkInfo != null){
        res.status(200).send({
            success: true,
            data: checkInfo,
            message:"",
        });
}else{
    res.status(200).send({
        success: false,
        data: null,
        message:"Not Found",
    });
}

  });
 
module.exports = {

    addContact,
    get_cms
    
}