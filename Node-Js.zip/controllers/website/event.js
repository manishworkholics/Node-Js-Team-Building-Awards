const express = require("express");
const parseJson = require('parse-json');
var md5 = require('md5');

const multer = require('multer');
const mkdirp = require('mkdirp');
const path = require('path');
const fs = require('fs');

const Sequelize = require('sequelize')
const { Op } = require("sequelize");
var dateFormat = require('dateformat');

const nodemailer = require("nodemailer");

const stripe = require('stripe')('sk_test_51K6T9KKuwTwCP2K3mlJKiBUS20LRhroFoFvkZSIyz2RoUw404tPb4LyElk8R1Qt9Ux0ZtqoTHWYeI1wZQxHpalZZ00Li2G3vpd');

const {
    Host,
    Event,
    MasterCategory,
    Category,
    Booking,
    Guest,
    sequelize
} = require('../../helpers/DBConnect');


const addEvent = (async (req,res)=>{
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

  let checkInfo = null;
  checkInfo = await Host.findOne({
      where: {
        host_id: req.body.host_id
      }
  });

  var sts = 0;
  if(checkInfo.dataValues.form_type==0){
    sts = 0;
  }

//   if(checkInfo.dataValues.form_type!=0){

const schedule = {
    'monday_close':req.body.monday_close,
    'monday_start':req.body.monday_start,
    'monday_end':req.body.monday_end,

    'tuesday_close':req.body.tuesday_close,
    'tuesday_start':req.body.tuesday_start,
    'tuesday_end':req.body.tuesday_end,

    'wednesday_close':req.body.wednesday_close,
    'wednesday_start':req.body.wednesday_start,
    'wednesday_end':req.body.wednesday_end,

    'thursday_close':req.body.thursday_close,
    'thursday_start':req.body.thursday_start,
    'thursday_end':req.body.thursday_end,

    'friday_close':req.body.friday_close,
    'friday_start':req.body.friday_start,
    'friday_end':req.body.friday_end,

    'saturday_close':req.body.saturday_close,
    'saturday_start':req.body.saturday_start,
    'saturday_end':req.body.saturday_end,

    'sunday_close':req.body.sunday_close,
    'sunday_start':req.body.sunday_start,
    'sunday_end':req.body.sunday_end,
}

  const eventResponse = await Event.create({
    host_id: req.body.host_id,
    title: req.body.title,
    image: req.body.image,
    image_one: req.body.image_one,
    image_two: req.body.image_two,
    image_three: req.body.image_three,
    image_four: req.body.image_four,
    short_description: req.body.short_description,
    description: req.body.description,
    phone_number: req.body.phone_number,
    no_of_guests: req.body.no_of_guests,
    min_guests: req.body.min_guests,
    price_per_guest: req.body.price_per_guest,
    event_duration: req.body.event_duration,
    master_category_id: req.body.master_category_id,
    category_id: req.body.category_id,
    start_date: req.body.start_date,
    start_time: req.body.start_time,
    schedule:schedule,
    event_meeting_link: req.body.event_meeting_link,
    how_it_works: req.body.how_it_works,
    kit_contents: req.body.kit_contents,
    things_guests_need: req.body.things_guests_need,
    status: sts
});

if(eventResponse){
    res.status(200).send({
        success: true,
        data: null,
        message:"Event Created Successfully...!",
    });
}

// }else{
//     res.status(200).send({
//         success: false,
//         data: null,
//         message:"First Upload Form...!",
//     });
// }
    
  });

  const list_category = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
       const categoryInfo = await Category.findAll();

       const categoryArr = [];
        if(categoryInfo.length > 0){
            for(var i=0;i<categoryInfo.length;i++){
                var arr = {
                    'category_id':categoryInfo[i]['category_id'],
                    'master_category_id':categoryInfo[i]['master_category_id'],
                    'name':categoryInfo[i]['name'],
                    'status':categoryInfo[i]['status'],
                    'createdAt':categoryInfo[i]['createdAt'],
                    'updatedAt':categoryInfo[i]['updatedAt'],
                }
                categoryArr.push(arr);
            }
        }

       res.status(200).send({
            success: true,
            data: categoryArr,
            message:"",
        });
  });

  const list_category_filtered = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
       const categoryInfo = await Category.findAll({
        where: {
          master_category_id: req.body.master_category_id
        }
    });

       const categoryArr = [];
        if(categoryInfo.length > 0){
            for(var i=0;i<categoryInfo.length;i++){

                const checkEventInfo = await Event.findAll({
                    where: {
                        category_id: categoryInfo[i]['category_id']
                    }
                });
                if(checkEventInfo.length>0){

                    var arr = {
                        'category_id':categoryInfo[i]['category_id'],
                        'name':categoryInfo[i]['name'],
                        'status':categoryInfo[i]['status'],
                        'createdAt':categoryInfo[i]['createdAt'],
                        'updatedAt':categoryInfo[i]['updatedAt'],
                    }
                    categoryArr.push(arr);
                }
            }
        }

       res.status(200).send({
            success: true,
            data: categoryArr,
            message:"",
        });
  });

  const list_master_category = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
       const categoryInfo = await MasterCategory.findAll();

       const categoryArr = [];
        if(categoryInfo.length > 0){
            for(var i=0;i<categoryInfo.length;i++){

                const checkCatInfo = await Category.findAll({
                    where: {
                        master_category_id: categoryInfo[i]['master_category_id']
                    }
                });

                const allCat = [];
                if(checkCatInfo!=null){
                    if(checkCatInfo.length>0){
                        for(var j=0;j<checkCatInfo.length;j++){

                            const checkEventInfo = await Event.findAll({
                                where: {
                                    category_id: checkCatInfo[j]['category_id']
                                }
                            });
                            if(checkEventInfo.length>0){
                                var arr2 = {
                                    'category_id':checkCatInfo[j]['category_id'],
                                    'name':checkCatInfo[j]['name']
                                }

                                allCat.push(arr2);
                            }
                        }
                    }
                }

                var arr = {
                    'master_category_id':categoryInfo[i]['master_category_id'],
                    'name':categoryInfo[i]['name'],
                    'status':categoryInfo[i]['status'],
                    'createdAt':categoryInfo[i]['createdAt'],
                    'updatedAt':categoryInfo[i]['updatedAt'],
                    'sub_cat':allCat
                }
                categoryArr.push(arr);
            }
        }

       res.status(200).send({
            success: true,
            data: categoryArr,
            message:"",
        });
  });


  const list_events = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    var current_date = dateFormat("yyyy-mm-dd");
    var current_time = dateFormat("hh:MM");
    var current = dateFormat("yyyy-mm-dd hh:MM:ss");

    let eventInfo;
    let limit = '';
    let where = '';
    if(req.body.page == 1){
      limit += " LIMIT 12";
    }else if(req.body.page == 3){
        limit += " LIMIT 6";
      }else{
        limit += "";
    }

    if(req.body.host_id){
        where += " WHERE e.host_id = "+req.body.host_id;
    }else{
        where += " WHERE e.status = 1 ";
    }

    // if(req.body.type == 1){
    //     where += " AND e.start_date <= '"+current_date+"' AND e.start_time <= '"+current_time+"' ";
    // }else if(req.body.type == 2){
    //     where += " AND e.start_date >= '"+current_date+"' AND e.start_time >= '"+current_time+"' ";
    // }

    if(req.body.type == 1){
       // where += " AND CONCAT(e.start_date,' ',e.start_time) <= '"+current+"' ";
    }else if(req.body.type == 2){
      //  where += " AND CONCAT(e.start_date,' ',e.start_time) >= '"+current+"' ";
    }

    if(req.body.selectMasterCategory!=undefined && req.body.selectMasterCategory!=""){
        where += " AND e.master_category_id = "+req.body.selectMasterCategory;
    }

    if(req.body.selectCategory!=undefined && req.body.selectCategory!=""){
        where += " AND e.category_id = "+req.body.selectCategory;
    }

    if(req.body.selectDuration!=undefined && req.body.selectDuration!=""){
        where += " AND e.event_duration = "+req.body.selectDuration;
    }

    if(req.body.selectPrice!=undefined && req.body.selectPrice!=""){

        var selectPrice_split = req.body.selectPrice.split('-');
        if(selectPrice_split.length == 2){
        var min_price = selectPrice_split[0];
        var max_price = selectPrice_split[1];

        where += " AND (e.price_per_guest >= "+min_price+" AND e.price_per_guest <= "+max_price+")";
        }else{
            var min_price = selectPrice_split[0];
            where += " AND e.price_per_guest >= "+min_price;
        }
    }

    if(req.body.selectGroup!=undefined && req.body.selectGroup!=""){

        var selectGroup_split = req.body.selectGroup.split('-');
        if(selectGroup_split.length == 2){
            var min_group = selectGroup_split[0];
            var max_group = selectGroup_split[1];

            //where += " AND (e.no_of_guests >= "+min_group+" AND e.no_of_guests <= "+max_group+")";
            where += " AND (e.no_of_guests <= "+max_group+")";
        }else{
           // var min_group = selectGroup_split[0];
           // where += " AND e.no_of_guests >= "+min_group;
        }
    }

    

    await sequelize.query("SELECT e.event_id, e.host_id, e.title, e.image as event_image, e.image_one as event_image_one, e.image_two as event_image_two, e.image_three as event_image_three, e.image_four as event_image_four, e.short_description, e.description, e.phone_number, e.no_of_guests, e.min_guests, e.price_per_guest, e.event_duration, e.category_id, e.start_date, e.start_time, e.schedule, e.event_meeting_link, e.how_it_works, e.kit_contents, e.things_guests_need, e.master_category_id, e.status, e.createdAt, h.first_name, h.last_name, h.image as host_image, c.name as category_name FROM Events e LEFT JOIN Hosts h ON(e.host_id=h.host_id) LEFT JOIN Categories c ON(c.category_id=e.category_id) "+where+" ORDER BY e.event_id DESC "+limit+" ", { type: sequelize.QueryTypes.SELECT }).then(async (eventData) => {
      eventInfo = eventData;
      });

      const eventArr = [];
      if(eventInfo.length > 0){
          for(var i=0;i<eventInfo.length;i++){

            if(eventInfo[i]['host_image'] != null){
                var host_img = process.env.MAIN_URL + 'uploads/' + eventInfo[i]['host_image'];
            }else{
                var host_img = process.env.MAIN_URL + 'images/user-img.png';
            }

            let checkGuest = null;
            // checkGuest = await Guest.findAll({
            //     where: {
            //         event_id: eventInfo[i]['event_id']
            //     }
            // });

            // .replace(/<[^>]*>?/gm, '')
              var arr = {
                  'event_id':eventInfo[i]['event_id'],
                  'title':eventInfo[i]['title'],
                  'event_image':process.env.MAIN_URL + 'uploads/' + eventInfo[i]['event_image'],
                  'event_image_one':eventInfo[i]['event_image_one'] != null ? process.env.MAIN_URL + 'uploads/' + eventInfo[i]['event_image_one'] : '',
                  'event_image_two':eventInfo[i]['event_image_two'] != null ? process.env.MAIN_URL + 'uploads/' + eventInfo[i]['event_image_two'] : '',
                  'event_image_three':eventInfo[i]['event_image_three'] != null ? process.env.MAIN_URL + 'uploads/' + eventInfo[i]['event_image_three'] : '',
                  'event_image_four':eventInfo[i]['event_image_two'] != null ? process.env.MAIN_URL + 'uploads/' + eventInfo[i]['event_image_four'] : '',
                  'description':eventInfo[i]['description'],
                  'short_description':eventInfo[i]['short_description'],
                  'no_of_guests':eventInfo[i]['no_of_guests'],
                  'min_guests':eventInfo[i]['min_guests'],
                  'price_per_guest':eventInfo[i]['price_per_guest'],
                  'event_duration':eventInfo[i]['event_duration'],
                  'start_date':eventInfo[i]['start_date'],
                  'start_time':eventInfo[i]['start_time'],
                  'event_meeting_link':eventInfo[i]['event_meeting_link'],
                  'how_it_works':eventInfo[i]['how_it_works'],
                  'kit_contents':eventInfo[i]['kit_contents'],
                  'things_guests_need':eventInfo[i]['things_guests_need'],
                  'host_id':eventInfo[i]['host_id'],
                 // 'host_name':eventInfo[i]['first_name']+' '+eventInfo[i]['last_name'],
                  'host_name':eventInfo[i]['first_name'],
                  'master_category_id':eventInfo[i]['master_category_id'],
                  'category_name':eventInfo[i]['category_name'],
                  'category_id':eventInfo[i]['category_id'],
                  'host_image':host_img,
                  'status':eventInfo[i]['status'],
                  'schedule':JSON.parse(eventInfo[i]['schedule']),
                  'createdAt':dateFormat(eventInfo[i]['createdAt'], "yyyy-mm-dd h:MM"),
                  'no_of_attend_guests':checkGuest
              }
              eventArr.push(arr);
          }
          
      }

       res.status(200).send({
            success: true,
            data: eventArr,
            message:"",
        });

});



const update_event = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    const schedule = {
        'monday_close':req.body.monday_close,
        'monday_start':req.body.monday_start,
        'monday_end':req.body.monday_end,
    
        'tuesday_close':req.body.tuesday_close,
        'tuesday_start':req.body.tuesday_start,
        'tuesday_end':req.body.tuesday_end,
    
        'wednesday_close':req.body.wednesday_close,
        'wednesday_start':req.body.wednesday_start,
        'wednesday_end':req.body.wednesday_end,
    
        'thursday_close':req.body.thursday_close,
        'thursday_start':req.body.thursday_start,
        'thursday_end':req.body.thursday_end,
    
        'friday_close':req.body.friday_close,
        'friday_start':req.body.friday_start,
        'friday_end':req.body.friday_end,
    
        'saturday_close':req.body.saturday_close,
        'saturday_start':req.body.saturday_start,
        'saturday_end':req.body.saturday_end,
    
        'sunday_close':req.body.sunday_close,
        'sunday_start':req.body.sunday_start,
        'sunday_end':req.body.sunday_end,
    }

    const eventResponse = await Event.update({
        title: req.body.title,
        image: req.body.image,
        image_one: req.body.image_one,
        image_two: req.body.image_two,
        image_three: req.body.image_three,
        image_four: req.body.image_four,
        short_description: req.body.short_description,
        description: req.body.description,
        phone_number: req.body.phone_number,
        no_of_guests: req.body.no_of_guests,
        min_guests: req.body.min_guests,
        price_per_guest: req.body.price_per_guest,
        event_duration: req.body.event_duration,
        master_category_id: req.body.master_category_id,
        category_id: req.body.category_id,
        start_date: req.body.start_date,
        start_time: req.body.start_time,
        schedule:schedule,
        event_meeting_link: req.body.event_meeting_link,
        how_it_works: req.body.how_it_works,
        kit_contents: req.body.kit_contents,
        things_guests_need: req.body.things_guests_need,
    },{
        where:{
            event_id:req.body.event_id
        }
    });
    
    if(eventResponse){
        res.status(200).send({
            success: true,
            data: null,
            message:"Event updated successfully",
        });
    }

});

const delete_event = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    var eventInfo = await Event.destroy({
        where: {
            event_id:req.body.event_id
        }
    });

    if(eventInfo){
        res.status(200).send({
            success: true,
            data: null,
            message:"Event deleted successfully",
        });
    }

});

const event_book = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");


    const contact_details = JSON.parse(req.body.contact_details);
    const billing_address = JSON.parse(req.body.billing_address);

    var add_guest_pass = Math.floor(10000000 + Math.random() * 90000000);
    var list_guest_pass = Math.floor(10000000 + Math.random() * 90000000);
 
      const eventResponse = await Booking.create({
        event_id: req.body.event_id,
        event_date: req.body.event_date,
        event_time: req.body.event_time,
        event_attendees: req.body.event_attendees,
        price: req.body.price,
        total: req.body.total,
        company_name: contact_details['company_name'],
        first_name: contact_details['first_name'],
        last_name: contact_details['last_name'],
        email: contact_details['email'],
        phone: contact_details['phone'],
        // billing_address_one: billing_address['address_one'],
        // billing_address_two: billing_address['address_two'],
        billing_address_one: req.body.billAddressOne,
        billing_address_two: req.body.billAddressTwo,
        country:billing_address['country'],
        state: billing_address['state'],
        city: billing_address['city'],
        post_code: billing_address['post_code'],
        add_guest_pass: add_guest_pass,
        list_guest_pass: list_guest_pass,
        status: 1
    });
    
    if(eventResponse){

        var name = contact_details['first_name']+' '+contact_details['last_name'];
        var add_guest_link = process.env.WEB_URL+"guest-info-add/"+md5(eventResponse.dataValues.booking_id.toString());
        var list_guest_link = process.env.WEB_URL+"guest-info-list/"+md5(eventResponse.dataValues.booking_id.toString());

        sendMailOneGuestsFun(name,contact_details['email'],add_guest_link,list_guest_link,add_guest_pass,list_guest_pass);

        // const guests_details = JSON.parse(req.body.guests_details);

        // if(guests_details.length>0){
        //     for(var i=0;i<guests_details.length;i++){
        //         const guestResponse = await Guest.create({
        //             booking_id: eventResponse.dataValues.booking_id,
        //             event_id: req.body.event_id,
        //             name: guests_details[i]['name'],
        //             last_name: guests_details[i]['last_name'],
        //             email: guests_details[i]['email'],
        //             phone_number: guests_details[i]['phone'],
        //             address: '',
        //             status: 1
        //         });



        //         var name = guests_details[i]['name']+' '+guests_details[i]['last_name'];
        //         var link = "http://18.221.10.104/guest-info-add/"+md5(guestResponse.dataValues.guest_id.toString());
        //         sendMailGuestsFun(name,guests_details[i]['email'],link);



        //     }
        // }

        res.status(200).send({
            success: true,
            data: null,
            message:"Payment Pay Successfully...!",
        });
    }
});

const check_event_booked = (async (req,res)=>{
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    // const eventInfo = await Event.findOne({
    //     where: {
    //         event_id: req.body.event_id
    //     }
    // });

    const all_time = JSON.parse(req.body.all_time);

    let guestInfo;
    let where = '';

    if(req.body.event_date!=undefined && req.body.event_date!=""){
        where += " event_date LIKE '%"+dateFormat(req.body.event_date, "yyyy-mm-dd")+"%' AND event_id = "+req.body.event_id;
    }

    await sequelize.query("SELECT event_time FROM Bookings WHERE "+where+" ", { type: sequelize.QueryTypes.SELECT }).then(async (eventData) => {
        guestInfo = eventData;
        });

        let checkEvent = null;
        checkEvent = await Event.findOne({
            where: {
                event_id: req.body.event_id
            }
        });

        const arrs = [];
        if(guestInfo.length>0){
            for(var i=0;i<guestInfo.length;i++){
                if(all_time.includes(guestInfo[i]['event_time']) == true){
                    //console.log("A",all_time.indexOf(guestInfo[i]['event_time']));
                    var get_index = all_time.indexOf(guestInfo[i]['event_time']);
                    arrs.push(all_time[get_index - parseInt(1)]);
                    if(checkEvent['event_duration']=='90'){
                        arrs.push(all_time[get_index - parseInt(2)]);
                    }
                    if(checkEvent['event_duration']=='120'){
                        arrs.push(all_time[get_index - parseInt(2)]);
                        arrs.push(all_time[get_index - parseInt(3)]);
                    }

                    arrs.push(all_time[get_index + parseInt(1)]);
                    if(checkEvent['event_duration']=='90'){
                        arrs.push(all_time[get_index + parseInt(2)]);
                    }
                    if(checkEvent['event_duration']=='120'){
                        arrs.push(all_time[get_index + parseInt(2)]);
                        arrs.push(all_time[get_index + parseInt(3)]);
                    }
                }
                arrs.push(guestInfo[i]['event_time']);
            }
        }

        res.status(200).send({
            success: true,
            data: arrs,
            message:"",
        });

});


const list_guests = (async (req,res)=>{

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");


    const guestInfo = await Booking.findAll({
        where: {
            event_id: req.body.event_id
        },
        order: [
            ['booking_id', 'DESC'],
          ],
    });

       const guestArr = [];
        if(guestInfo.length > 0){
            for(var i=0;i<guestInfo.length;i++){
                
                const guestInfos = await Guest.findAll({
                    where: {
                        booking_id: guestInfo[i]['booking_id']
                    }
                });

                var arr = {
                    'booking_id':guestInfo[i]['booking_id'],
                    'event_id':guestInfo[i]['event_id'],
                    'event_date':guestInfo[i]['event_date'],
                    'event_time':guestInfo[i]['event_time'],
                    'event_attendees':guestInfo[i]['event_attendees'],
                    'company_name':guestInfo[i]['company_name'],
                    'first_name':guestInfo[i]['first_name'],
                    'last_name':guestInfo[i]['last_name'],
                    'email':guestInfo[i]['email'],
                    'phone':guestInfo[i]['phone'],
                    'billing_address_one':guestInfo[i]['billing_address_one'],
                    'billing_address_two':guestInfo[i]['billing_address_two'],
                    'country':guestInfo[i]['country'],
                    'state':guestInfo[i]['state'],
                    'city':guestInfo[i]['city'],
                    'post_code':guestInfo[i]['post_code'],
                    'price':guestInfo[i]['price'],
                    'total':guestInfo[i]['total'],
                    'createdAt':dateFormat(guestInfo[i]['createdAt'], "yyyy-mm-dd h:MM"),
                    'guests':guestInfos
                }

                guestArr.push(arr);
            }
        }

       res.status(200).send({
            success: true,
            data: guestArr,
            message:"",
        });

});

const pay_payment = (async (req,res)=>{
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Accept', 'application/json');

    try {
        // Create the PaymentIntent
        let intent = await stripe.paymentIntents.create({
          payment_method: request.body.payment_method_id,
          description: "Test payment",
          amount: request.body.amount * 100,
          currency: 'inr',
          confirmation_method: 'manual',
          confirm: true
        });
        // Send the response to the client
        response.send(generateResponse(intent));
      } catch (e) {
        // Display error on client
        return response.send({ error: e.message });
      }
});

const generateResponse = (intent) => {
    if (intent.status === 'succeeded') {
      // The payment didn’t need any additional actions and completed!
      // Handle post-payment fulfillment
      return {
        success: true
      };
    } else {
      // Invalid status
      return {
        error: 'Invalid PaymentIntent status'
      };
    }
  };

module.exports = {

    addEvent,
    list_master_category,
    list_category,
    list_category_filtered,
    list_events,
    update_event,
    delete_event,
    event_book,
    check_event_booked,
    list_guests,
    pay_payment
}

async function sendMailGuestsFun(name,email,link){
    // Mail Send
  
   // let testAccount = await nodemailer.createTestAccount();
  
    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
      host: process.env.MAIL_HOST,
      port: process.env.MAIL_PORT,
      //secure: false, // true for 465, false for other ports
      auth: {
          user: process.env.MAIL_USER,
          pass: process.env.MAIL_PASS,
      },
      });
  
    var htm = '<html lang="en-US"><head><meta content="text/html; charset=utf-8" http-equiv="Content-Type" /><title>Elloro</title><meta name="description" content="Email Template."><style type="text/css">a:hover {text-decoration: underline !important;}</style></head> <body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0"><table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: sans-serif;"><tr><td><table style="background-color: #f2f3f8; max-width:670px;  margin:0 auto;" width="100%" border="0" align="center" cellpadding="0" cellspacing="0"><tr><td style="height:80px;">&nbsp;</td></tr><tr><td style="text-align:center;"><a href="" title="logo" target="_blank"><img src="'+process.env.WEB_URL+'assets/images/logo.png" title="logo" alt="logo"></a></td></tr><tr><td style="height:20px;">&nbsp;</td></tr><tr><td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" style="max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);"><tr><td style="height:40px;">&nbsp;</td></tr><tr><td style="padding:0 35px;"><p style=" margin:0;font-size:18px;font-family:sans-serif;">Hi <b>'+name+'</b>, <br/></p><span style="display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; width:100px;"></span><p style=" font-size:15px;line-height:24px; margin:0;">Your Link is: <a href='+link+'>'+link+'</a></p><br><br><br>The Team Building Awards Team </td></tr><tr><td style="height:40px;">&nbsp;</td></tr></table></td><tr><td style="height:20px;">&nbsp;</td></tr><tr><td style="height:80px;">&nbsp;</td></tr></table></td></tr></table></body></html>';
  
    // send mail with defined transport object
    let info = await transporter.sendMail({
      from: process.env.MAIL_USER, // sender address
      to: email, // list of receivers
      subject: "Team Building Awards Event Guest", // Subject line
      text: "Team Building Awards Event Guest", // plain text body
      html: htm, // html body
    });
    // =========
  }


  async function sendMailOneGuestsFun(name,email,add_guest_link,list_guest_link,add_guest_pass,list_guest_pass){
    // Mail Send
  
   // let testAccount = await nodemailer.createTestAccount();
  
    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
      host: process.env.MAIL_HOST,
      port: process.env.MAIL_PORT,
      //secure: false, // true for 465, false for other ports
      auth: {
          user: process.env.MAIL_USER,
          pass: process.env.MAIL_PASS,
      },
      });
  
    var htm = '<html lang="en-US"><head><meta content="text/html; charset=utf-8" http-equiv="Content-Type" /><title>Elloro</title><meta name="description" content="Email Template."><style type="text/css">a:hover {text-decoration: underline !important;}</style></head> <body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0"><table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: sans-serif;"><tr><td><table style="background-color: #f2f3f8; max-width:670px;  margin:0 auto;" width="100%" border="0" align="center" cellpadding="0" cellspacing="0"><tr><td style="height:80px;">&nbsp;</td></tr><tr><td style="text-align:center;"><a href="" title="logo" target="_blank"><img src="'+process.env.WEB_URL+'assets/images/logo.png" title="logo" alt="logo"></a></td></tr><tr><td style="height:20px;">&nbsp;</td></tr><tr><td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" style="max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);"><tr><td style="height:40px;">&nbsp;</td></tr><tr><td style="padding:0 35px;"><p style=" margin:0;font-size:18px;font-family:sans-serif;">Hi <b>'+name+'</b>, <br/></p><span style="display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; width:100px;"></span><p style=" font-size:15px;line-height:24px; margin:0;">Your Guests Participation Link is: <a href='+add_guest_link+'>'+add_guest_link+'</a></p><br><p style=" font-size:15px;line-height:24px; margin:0;">Your Guests Participation Password is: '+add_guest_pass+'</p><br><br><br><p style=" font-size:15px;line-height:24px; margin:0;">Your Guests Participated List Link is: <a href='+list_guest_link+'>'+list_guest_link+'</a></p><br><p style=" font-size:15px;line-height:24px; margin:0;">Your Guests Participation Password is: '+list_guest_pass+'</p><br><br><br>The Team Building Awards Team </td></tr><tr><td style="height:40px;">&nbsp;</td></tr></table></td><tr><td style="height:20px;">&nbsp;</td></tr><tr><td style="height:80px;">&nbsp;</td></tr></table></td></tr></table></body></html>';
  
    // send mail with defined transport object
    let info = await transporter.sendMail({
      from: process.env.MAIL_USER, // sender address
      to: email, // list of receivers
      subject: "Team Building Awards Event Booked", // Subject line
      text: "Team Building Awards Event Booked", // plain text body
      html: htm, // html body
    });
    // =========
  }